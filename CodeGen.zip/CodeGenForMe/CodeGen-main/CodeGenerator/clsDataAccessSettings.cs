﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerator
{
    public class clsDataAccessSettings
    {
        public static string ConnectionString = "Data Source=.;Integrated Security=True;TrustServerCertificate=True;";
    }

}
