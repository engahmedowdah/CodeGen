﻿namespace CodeGen
{
    partial class frmCodeGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCodeGen));
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.cbDatabases = new System.Windows.Forms.ComboBox();
            this.lblTitleName = new System.Windows.Forms.Label();
            this.rtbGeneratedCode = new System.Windows.Forms.RichTextBox();
            this.btnSelectMethods = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.lvTables = new System.Windows.Forms.ListView();
            this.chTable = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvColumns = new System.Windows.Forms.ListView();
            this.chColumnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chDataType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chAllowNull = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chIsPrimryKey = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chLinkedTable = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnGenerateDataAccessLayer = new System.Windows.Forms.Button();
            this.btnGenerateBusinessLayer = new System.Windows.Forms.Button();
            this.btnGenerateDataAccessSettings = new System.Windows.Forms.Button();
            this.btnAdvancedGenerating = new System.Windows.Forms.Button();
            this.lblCode = new System.Windows.Forms.Label();
            this.pbDatabaseImage = new System.Windows.Forms.PictureBox();
            this.pbCodeGenImage = new System.Windows.Forms.PictureBox();
            this.btnMinimizeScreen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDatabaseImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCodeGenImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.AutoSize = true;
            this.pnlHeader.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlHeader.Controls.Add(this.cbDatabases);
            this.pnlHeader.Controls.Add(this.pbDatabaseImage);
            this.pnlHeader.Controls.Add(this.pbCodeGenImage);
            this.pnlHeader.Controls.Add(this.lblTitleName);
            this.pnlHeader.Controls.Add(this.btnMinimizeScreen);
            this.pnlHeader.Controls.Add(this.btnClose);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1697, 77);
            this.pnlHeader.TabIndex = 0;
            this.pnlHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // cbDatabases
            // 
            this.cbDatabases.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbDatabases.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbDatabases.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDatabases.FormattingEnabled = true;
            this.cbDatabases.Location = new System.Drawing.Point(92, 26);
            this.cbDatabases.Name = "cbDatabases";
            this.cbDatabases.Size = new System.Drawing.Size(180, 24);
            this.cbDatabases.TabIndex = 1;
            this.cbDatabases.SelectedIndexChanged += new System.EventHandler(this.cbDatabases_SelectedIndexChanged);
            // 
            // lblTitleName
            // 
            this.lblTitleName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTitleName.AutoSize = true;
            this.lblTitleName.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold);
            this.lblTitleName.Location = new System.Drawing.Point(649, 16);
            this.lblTitleName.Name = "lblTitleName";
            this.lblTitleName.Size = new System.Drawing.Size(189, 50);
            this.lblTitleName.TabIndex = 2;
            this.lblTitleName.Text = "Code Gen";
            this.lblTitleName.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // rtbGeneratedCode
            // 
            this.rtbGeneratedCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.rtbGeneratedCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbGeneratedCode.ForeColor = System.Drawing.Color.Snow;
            this.rtbGeneratedCode.Location = new System.Drawing.Point(1204, 105);
            this.rtbGeneratedCode.Name = "rtbGeneratedCode";
            this.rtbGeneratedCode.ReadOnly = true;
            this.rtbGeneratedCode.Size = new System.Drawing.Size(455, 556);
            this.rtbGeneratedCode.TabIndex = 3;
            this.rtbGeneratedCode.Text = "";
            // 
            // btnSelectMethods
            // 
            this.btnSelectMethods.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnSelectMethods.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectMethods.ForeColor = System.Drawing.Color.White;
            this.btnSelectMethods.Location = new System.Drawing.Point(1204, 750);
            this.btnSelectMethods.Name = "btnSelectMethods";
            this.btnSelectMethods.Size = new System.Drawing.Size(456, 40);
            this.btnSelectMethods.TabIndex = 8;
            this.btnSelectMethods.Text = "Select Methods";
            this.btnSelectMethods.UseVisualStyleBackColor = false;
            this.btnSelectMethods.Click += new System.EventHandler(this.btnSelectMethods_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnCopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCopy.ForeColor = System.Drawing.Color.White;
            this.btnCopy.Location = new System.Drawing.Point(1204, 695);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(456, 40);
            this.btnCopy.TabIndex = 9;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = false;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // lvTables
            // 
            this.lvTables.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvTables.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.lvTables.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chTable});
            this.lvTables.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lvTables.ForeColor = System.Drawing.Color.White;
            this.lvTables.FullRowSelect = true;
            this.lvTables.GridLines = true;
            this.lvTables.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvTables.HideSelection = false;
            this.lvTables.Location = new System.Drawing.Point(12, 105);
            this.lvTables.MultiSelect = false;
            this.lvTables.Name = "lvTables";
            this.lvTables.Size = new System.Drawing.Size(266, 681);
            this.lvTables.TabIndex = 12;
            this.lvTables.UseCompatibleStateImageBehavior = false;
            this.lvTables.View = System.Windows.Forms.View.Details;
            this.lvTables.SelectedIndexChanged += new System.EventHandler(this.lvTables_SelectedIndexChanged);
            // 
            // chTable
            // 
            this.chTable.Text = " TableName";
            this.chTable.Width = 260;
            // 
            // lvColumns
            // 
            this.lvColumns.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvColumns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.lvColumns.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chColumnName,
            this.chDataType,
            this.chAllowNull,
            this.chIsPrimryKey,
            this.chLinkedTable});
            this.lvColumns.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.lvColumns.FullRowSelect = true;
            this.lvColumns.GridLines = true;
            this.lvColumns.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvColumns.HideSelection = false;
            this.lvColumns.Location = new System.Drawing.Point(311, 105);
            this.lvColumns.MultiSelect = false;
            this.lvColumns.Name = "lvColumns";
            this.lvColumns.Size = new System.Drawing.Size(848, 556);
            this.lvColumns.TabIndex = 13;
            this.lvColumns.UseCompatibleStateImageBehavior = false;
            this.lvColumns.View = System.Windows.Forms.View.Details;
            // 
            // chColumnName
            // 
            this.chColumnName.Text = "ColumnName";
            this.chColumnName.Width = 180;
            // 
            // chDataType
            // 
            this.chDataType.Text = "DataType";
            this.chDataType.Width = 125;
            // 
            // chAllowNull
            // 
            this.chAllowNull.Text = "AllowNull";
            this.chAllowNull.Width = 105;
            // 
            // chIsPrimryKey
            // 
            this.chIsPrimryKey.Text = "IsPrimryKey";
            this.chIsPrimryKey.Width = 105;
            // 
            // chLinkedTable
            // 
            this.chLinkedTable.Text = "TheLinkedTable";
            this.chLinkedTable.Width = 124;
            // 
            // btnGenerateDataAccessLayer
            // 
            this.btnGenerateDataAccessLayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateDataAccessLayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateDataAccessLayer.ForeColor = System.Drawing.Color.White;
            this.btnGenerateDataAccessLayer.Location = new System.Drawing.Point(311, 695);
            this.btnGenerateDataAccessLayer.Name = "btnGenerateDataAccessLayer";
            this.btnGenerateDataAccessLayer.Size = new System.Drawing.Size(403, 40);
            this.btnGenerateDataAccessLayer.TabIndex = 11;
            this.btnGenerateDataAccessLayer.Text = "Generate Data Access Class";
            this.btnGenerateDataAccessLayer.UseVisualStyleBackColor = false;
            this.btnGenerateDataAccessLayer.Click += new System.EventHandler(this.btnGenerateDataAccessLayer_Click);
            // 
            // btnGenerateBusinessLayer
            // 
            this.btnGenerateBusinessLayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateBusinessLayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateBusinessLayer.ForeColor = System.Drawing.Color.White;
            this.btnGenerateBusinessLayer.Location = new System.Drawing.Point(311, 750);
            this.btnGenerateBusinessLayer.Name = "btnGenerateBusinessLayer";
            this.btnGenerateBusinessLayer.Size = new System.Drawing.Size(403, 40);
            this.btnGenerateBusinessLayer.TabIndex = 6;
            this.btnGenerateBusinessLayer.Text = "Generate Business Class";
            this.btnGenerateBusinessLayer.UseVisualStyleBackColor = false;
            this.btnGenerateBusinessLayer.Click += new System.EventHandler(this.btnGenerateBusinessLayer_Click);
            // 
            // btnGenerateDataAccessSettings
            // 
            this.btnGenerateDataAccessSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateDataAccessSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateDataAccessSettings.ForeColor = System.Drawing.Color.White;
            this.btnGenerateDataAccessSettings.Location = new System.Drawing.Point(752, 695);
            this.btnGenerateDataAccessSettings.Name = "btnGenerateDataAccessSettings";
            this.btnGenerateDataAccessSettings.Size = new System.Drawing.Size(407, 40);
            this.btnGenerateDataAccessSettings.TabIndex = 10;
            this.btnGenerateDataAccessSettings.Text = "Generate Data Access Settings";
            this.btnGenerateDataAccessSettings.UseVisualStyleBackColor = false;
            this.btnGenerateDataAccessSettings.Click += new System.EventHandler(this.btnGenerateDataAccessSettings_Click);
            // 
            // btnAdvancedGenerating
            // 
            this.btnAdvancedGenerating.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnAdvancedGenerating.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdvancedGenerating.ForeColor = System.Drawing.Color.White;
            this.btnAdvancedGenerating.Location = new System.Drawing.Point(752, 750);
            this.btnAdvancedGenerating.Name = "btnAdvancedGenerating";
            this.btnAdvancedGenerating.Size = new System.Drawing.Size(407, 40);
            this.btnAdvancedGenerating.TabIndex = 7;
            this.btnAdvancedGenerating.Text = "Advanced Generating";
            this.btnAdvancedGenerating.UseVisualStyleBackColor = false;
            this.btnAdvancedGenerating.Click += new System.EventHandler(this.btnAdvancedGenerating_Click);
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCode.Location = new System.Drawing.Point(1268, 319);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(326, 128);
            this.lblCode.TabIndex = 14;
            this.lblCode.Text = resources.GetString("lblCode.Text");
            this.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbDatabaseImage
            // 
            this.pbDatabaseImage.Image = global::CodeGen.Properties.Resources.DB;
            this.pbDatabaseImage.Location = new System.Drawing.Point(28, 21);
            this.pbDatabaseImage.Name = "pbDatabaseImage";
            this.pbDatabaseImage.Size = new System.Drawing.Size(40, 40);
            this.pbDatabaseImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDatabaseImage.TabIndex = 4;
            this.pbDatabaseImage.TabStop = false;
            this.pbDatabaseImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // pbCodeGenImage
            // 
            this.pbCodeGenImage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbCodeGenImage.Image = global::CodeGen.Properties.Resources.Gen;
            this.pbCodeGenImage.Location = new System.Drawing.Point(844, 14);
            this.pbCodeGenImage.Name = "pbCodeGenImage";
            this.pbCodeGenImage.Size = new System.Drawing.Size(72, 55);
            this.pbCodeGenImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCodeGenImage.TabIndex = 3;
            this.pbCodeGenImage.TabStop = false;
            this.pbCodeGenImage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // btnMinimizeScreen
            // 
            this.btnMinimizeScreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizeScreen.BackgroundImage = global::CodeGen.Properties.Resources.minus;
            this.btnMinimizeScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMinimizeScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizeScreen.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnMinimizeScreen.Location = new System.Drawing.Point(1547, 16);
            this.btnMinimizeScreen.Name = "btnMinimizeScreen";
            this.btnMinimizeScreen.Size = new System.Drawing.Size(50, 50);
            this.btnMinimizeScreen.TabIndex = 1;
            this.btnMinimizeScreen.UseVisualStyleBackColor = true;
            this.btnMinimizeScreen.Click += new System.EventHandler(this.btnMinimizeScreen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackgroundImage = global::CodeGen.Properties.Resources.remove;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnClose.Location = new System.Drawing.Point(1621, 16);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 50);
            this.btnClose.TabIndex = 0;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmCodeGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1697, 802);
            this.Controls.Add(this.lblCode);
            this.Controls.Add(this.lvColumns);
            this.Controls.Add(this.lvTables);
            this.Controls.Add(this.btnGenerateBusinessLayer);
            this.Controls.Add(this.btnAdvancedGenerating);
            this.Controls.Add(this.btnSelectMethods);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnGenerateDataAccessSettings);
            this.Controls.Add(this.btnGenerateDataAccessLayer);
            this.Controls.Add(this.rtbGeneratedCode);
            this.Controls.Add(this.pnlHeader);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCodeGen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Code Generator";
            this.Load += new System.EventHandler(this.frmCodeGen_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDatabaseImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCodeGenImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.PictureBox pbCodeGenImage;
        private System.Windows.Forms.Label lblTitleName;
        private System.Windows.Forms.Button btnMinimizeScreen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cbDatabases;
        private System.Windows.Forms.PictureBox pbDatabaseImage;
        private System.Windows.Forms.RichTextBox rtbGeneratedCode;
        private System.Windows.Forms.Button btnSelectMethods;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.ListView lvTables;
        private System.Windows.Forms.ColumnHeader chTable;
        private System.Windows.Forms.ListView lvColumns;
        private System.Windows.Forms.ColumnHeader chColumnName;
        private System.Windows.Forms.ColumnHeader chDataType;
        private System.Windows.Forms.ColumnHeader chAllowNull;
        private System.Windows.Forms.ColumnHeader chIsPrimryKey;
        private System.Windows.Forms.ColumnHeader chLinkedTable;
        private System.Windows.Forms.Button btnGenerateDataAccessLayer;
        private System.Windows.Forms.Button btnGenerateBusinessLayer;
        private System.Windows.Forms.Button btnGenerateDataAccessSettings;
        private System.Windows.Forms.Button btnAdvancedGenerating;
        private System.Windows.Forms.Label lblCode;
    }
}