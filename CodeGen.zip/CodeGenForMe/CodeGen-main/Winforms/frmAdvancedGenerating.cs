﻿using CodeGen.Global;
using CodeGen_Business;
using CodeGen_Business.Business;
using CodeGen_DataAccess.DataAccess;
using CodeGen_DataAccess.DataAccessSettings;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace CodeGen
{
    public partial class frmAdvancedGenerating : Form
    {
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        private const int WM_NCLBUTTONDOWN = 0x00A1;
        private const int HTCAPTION = 0x0002;

        string DatabaseName { get; set; }
        clsDatabase dataBaseInfo;
        string SelectedPath = "";
        public frmAdvancedGenerating()
        {
            InitializeComponent();
            this.DatabaseName = clsGlobal.DatabaseName;
            dataBaseInfo = clsDatabase.GetDatabaseByName(DatabaseName);
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimizeScreen_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pbSelectFolder_Click(object sender, EventArgs e)
        {
            if (fbdSelectPath.ShowDialog() == DialogResult.OK)
            {
                SelectedPath = fbdSelectPath.SelectedPath;
                txtFolderPath.Text = SelectedPath;
            }
        }
        private bool IsFolderPathValid()
        {
            if (string.IsNullOrWhiteSpace(SelectedPath))
            {
                MessageBox.Show("You don't choose the file path", "File path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            return true;
        }

        private void btnGenerateDAL_Click(object sender, EventArgs e)
        {
            if (!IsFolderPathValid())
            {
                return;
            }
            else if (dataBaseInfo.TableList.Count == 0)
            {
                MessageForTablesEmpty();
                return;
            }
            else
            {
                List<string> codes = new List<string>();
                dataBaseInfo.TableList.ForEach(table =>
                {
                    codes.Add(new clsClassDataGen(DatabaseName, table.TableID).Generate().ToString());
                });

                string basePath = SelectedPath;

                foreach (clsTable tableInfo in dataBaseInfo.TableList)
                {
                    clsUtil.CreateFile(basePath, tableInfo.DataAccessClassName + ".cs", codes[tableInfo.TableID-1]);
                }

                MessageForComplete();
            }
        }

        private void btnGenerateDAS_Click(object sender, EventArgs e)
        {
            if (!IsFolderPathValid())
            {
                return;
            }

            string filePath = SelectedPath;

            clsUtil.CreateFile(filePath, dataBaseInfo.ClassWithDataAccessSettings + ".cs",
                               new clsClassDataAccessSettingsGen(DatabaseName).Generate().ToString());
            MessageForComplete();
        }


        private void btnGenerateBL_Click(object sender, EventArgs e)
        {
            if (!IsFolderPathValid())
            {
                return;
            }
            else if (dataBaseInfo.TableList.Count == 0)
            {
                MessageForTablesEmpty();
                return;
            }
            else
            {
                List<string> codes = new List<string>();
                dataBaseInfo.TableList.ForEach(table =>
                {
                    codes.Add(new clsClassGen(DatabaseName, table.TableID).Generate().ToString());
                });

                string basePath = SelectedPath;

                foreach (clsTable tableInfo in dataBaseInfo.TableList)
                {
                    clsUtil.CreateFile(basePath, tableInfo.BusinessClassName + ".cs", codes[tableInfo.TableID-1]);
                }

                MessageForComplete();
            }
        }

        static void ShowMessage(string message, string title, MessageBoxButtons messageBoxButtons, MessageBoxIcon messageBoxIcon)
        {
            MessageBox.Show(message, title, messageBoxButtons, messageBoxIcon);
        }

        static void MessageForComplete()
        {
            ShowMessage("All files have been successfully created. You can now proceed with your tasks.",
                         "Creation Complete",
                         MessageBoxButtons.OK,
                         MessageBoxIcon.Information);
        }

        static void MessageForTablesEmpty()
        {
            ShowMessage("The selected database is empty. Please choose a different database with existing tables.",
                         "Database Error",
                         MessageBoxButtons.OK,
                         MessageBoxIcon.Error);
        }

        static void MessageForClassesNotCreated()
        {
            ShowMessage("Some classes could not be created. Please provide details about the issue so we can assist you further.",
                         "Creation Error",
                         MessageBoxButtons.OK,
                         MessageBoxIcon.Error);
        }

        private void btnSelectMethods_Click(object sender, EventArgs e)
        {
            frmSelectFunctions advancedFunctionGeneration = new frmSelectFunctions();
            advancedFunctionGeneration.ShowDialog();
        }

        private void frmAdvancedGenerating_Load(object sender, EventArgs e)
        {
            LoadScreen();
        }

        private void LoadScreen()
        {
            lblSelectedDatabase.Text = this.DatabaseName;
        }

        private void Panel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }
    }
}
