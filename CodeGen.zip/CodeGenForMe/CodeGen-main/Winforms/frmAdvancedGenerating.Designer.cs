﻿namespace CodeGen
{
    partial class frmAdvancedGenerating
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdvancedGenerating));
            this.lblSelectedDatabase = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFolderPath = new System.Windows.Forms.TextBox();
            this.btnGenerateDAL = new System.Windows.Forms.Button();
            this.btnGenerateDAS = new System.Windows.Forms.Button();
            this.fbdSelectPath = new System.Windows.Forms.FolderBrowserDialog();
            this.btnGenerateBL = new System.Windows.Forms.Button();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectMethods = new System.Windows.Forms.Button();
            this.btnMinimizeScreen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pbSelectFolder = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSelectFolder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSelectedDatabase
            // 
            this.lblSelectedDatabase.AutoSize = true;
            this.lblSelectedDatabase.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedDatabase.Location = new System.Drawing.Point(7, 99);
            this.lblSelectedDatabase.Name = "lblSelectedDatabase";
            this.lblSelectedDatabase.Size = new System.Drawing.Size(215, 32);
            this.lblSelectedDatabase.TabIndex = 19;
            this.lblSelectedDatabase.Text = "Selected Database";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Database:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 16);
            this.label1.TabIndex = 22;
            this.label1.Text = "Select Folder:";
            // 
            // txtFolderPath
            // 
            this.txtFolderPath.Location = new System.Drawing.Point(12, 173);
            this.txtFolderPath.Multiline = true;
            this.txtFolderPath.Name = "txtFolderPath";
            this.txtFolderPath.ReadOnly = true;
            this.txtFolderPath.Size = new System.Drawing.Size(442, 30);
            this.txtFolderPath.TabIndex = 18;
            // 
            // btnGenerateDAL
            // 
            this.btnGenerateDAL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateDAL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateDAL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnGenerateDAL.Location = new System.Drawing.Point(12, 223);
            this.btnGenerateDAL.Name = "btnGenerateDAL";
            this.btnGenerateDAL.Size = new System.Drawing.Size(240, 40);
            this.btnGenerateDAL.TabIndex = 16;
            this.btnGenerateDAL.Text = "Generate Data Access Layer";
            this.btnGenerateDAL.UseVisualStyleBackColor = false;
            this.btnGenerateDAL.Click += new System.EventHandler(this.btnGenerateDAL_Click);
            // 
            // btnGenerateDAS
            // 
            this.btnGenerateDAS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateDAS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateDAS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnGenerateDAS.Location = new System.Drawing.Point(258, 223);
            this.btnGenerateDAS.Name = "btnGenerateDAS";
            this.btnGenerateDAS.Size = new System.Drawing.Size(240, 40);
            this.btnGenerateDAS.TabIndex = 17;
            this.btnGenerateDAS.Text = "Generate Data Access Settings";
            this.btnGenerateDAS.UseVisualStyleBackColor = false;
            this.btnGenerateDAS.Click += new System.EventHandler(this.btnGenerateDAS_Click);
            // 
            // btnGenerateBL
            // 
            this.btnGenerateBL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnGenerateBL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerateBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnGenerateBL.Location = new System.Drawing.Point(73, 273);
            this.btnGenerateBL.Name = "btnGenerateBL";
            this.btnGenerateBL.Size = new System.Drawing.Size(363, 40);
            this.btnGenerateBL.TabIndex = 23;
            this.btnGenerateBL.Text = "Generate Business Layer";
            this.btnGenerateBL.UseVisualStyleBackColor = false;
            this.btnGenerateBL.Click += new System.EventHandler(this.btnGenerateBL_Click);
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlHeader.Controls.Add(this.pictureBox1);
            this.pnlHeader.Controls.Add(this.label2);
            this.pnlHeader.Controls.Add(this.btnMinimizeScreen);
            this.pnlHeader.Controls.Add(this.btnClose);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(521, 56);
            this.pnlHeader.TabIndex = 24;
            this.pnlHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 32);
            this.label2.TabIndex = 25;
            this.label2.Text = "Advanced Generating";
            // 
            // btnSelectMethods
            // 
            this.btnSelectMethods.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(66)))));
            this.btnSelectMethods.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectMethods.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.btnSelectMethods.Location = new System.Drawing.Point(109, 319);
            this.btnSelectMethods.Name = "btnSelectMethods";
            this.btnSelectMethods.Size = new System.Drawing.Size(291, 40);
            this.btnSelectMethods.TabIndex = 25;
            this.btnSelectMethods.Text = "Select Methods";
            this.btnSelectMethods.UseVisualStyleBackColor = false;
            this.btnSelectMethods.Click += new System.EventHandler(this.btnSelectMethods_Click);
            // 
            // btnMinimizeScreen
            // 
            this.btnMinimizeScreen.BackgroundImage = global::CodeGen.Properties.Resources.minus;
            this.btnMinimizeScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMinimizeScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizeScreen.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnMinimizeScreen.Location = new System.Drawing.Point(392, 3);
            this.btnMinimizeScreen.Name = "btnMinimizeScreen";
            this.btnMinimizeScreen.Size = new System.Drawing.Size(50, 50);
            this.btnMinimizeScreen.TabIndex = 5;
            this.btnMinimizeScreen.UseVisualStyleBackColor = true;
            this.btnMinimizeScreen.Click += new System.EventHandler(this.btnMinimizeScreen_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImage = global::CodeGen.Properties.Resources.remove;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnClose.Location = new System.Drawing.Point(459, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 50);
            this.btnClose.TabIndex = 4;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pbSelectFolder
            // 
            this.pbSelectFolder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbSelectFolder.Image = global::CodeGen.Properties.Resources.open_folder;
            this.pbSelectFolder.Location = new System.Drawing.Point(460, 168);
            this.pbSelectFolder.Name = "pbSelectFolder";
            this.pbSelectFolder.Size = new System.Drawing.Size(49, 40);
            this.pbSelectFolder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSelectFolder.TabIndex = 12;
            this.pbSelectFolder.TabStop = false;
            this.pbSelectFolder.Click += new System.EventHandler(this.pbSelectFolder_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Image = global::CodeGen.Properties.Resources.Select_file;
            this.pictureBox1.Location = new System.Drawing.Point(7, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // frmAdvancedGenerating
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(521, 369);
            this.Controls.Add(this.btnSelectMethods);
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.btnGenerateBL);
            this.Controls.Add(this.lblSelectedDatabase);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFolderPath);
            this.Controls.Add(this.pbSelectFolder);
            this.Controls.Add(this.btnGenerateDAL);
            this.Controls.Add(this.btnGenerateDAS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmAdvancedGenerating";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Advanced Generating";
            this.Load += new System.EventHandler(this.frmAdvancedGenerating_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSelectFolder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelectedDatabase;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFolderPath;
        private System.Windows.Forms.PictureBox pbSelectFolder;
        private System.Windows.Forms.Button btnGenerateDAL;
        private System.Windows.Forms.Button btnGenerateDAS;
        private System.Windows.Forms.FolderBrowserDialog fbdSelectPath;
        private System.Windows.Forms.Button btnGenerateBL;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Button btnMinimizeScreen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSelectMethods;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}