﻿using CodeGen_Business.Business;
using CodeGen_DataAccess.DataAccess;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CodeGen.Global;
using GlobalGen;
using CodeGen_DataAccess.DataAccessSettings;
using System.Runtime.InteropServices;

namespace CodeGen
{
    public partial class frmCodeGen : Form
    {

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        private const int WM_NCLBUTTONDOWN = 0x00A1;
        private const int HTCAPTION = 0x0002;

        public frmCodeGen()
        {
            InitializeComponent();
        }

        private string TableName { get; set; } = "";
        private string DatabaseName { get; set; } = "";
        private clsDatabase DatabaseInfo { get; set; }

        private void _FillDatabaseCombobox()
        {
            List<clsDatabase> Databases = clsDatabase.GetAllDatabasesInList();

            foreach (clsDatabase Database in Databases)
            {
                cbDatabases.Items.Add(Database.DatabaseName);
            }
        }

        private void cbDatabases_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbDatabases.SelectedText == DatabaseName)
            {
                ShowLabelForMyDefinitions();
            }
            if (cbDatabases.SelectedItem != null)
            {
                DatabaseName = cbDatabases.SelectedItem.ToString();
                DatabaseInfo = clsDatabase.GetDatabaseByName(DatabaseName);
                clsGlobal.DatabaseName = DatabaseName;
                LoadTables(DatabaseName);
                rtbGeneratedCode.Text = string.Empty;
                ShowLabelForMyDefinitions();
            }
            else
            {
                ShowMessageBox("Please check for your databases.","Error for Databases", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static void ShowMessageBox(string message, string Title, MessageBoxButtons messageBoxButtons, MessageBoxIcon messageBoxIcon)
        {
            MessageBox.Show(message, Title, messageBoxButtons, messageBoxIcon);
        }

        private void LoadTables(string databaseName)
        {
            lvTables.Items.Clear();
            foreach (clsTable tableInfo in DatabaseInfo.TableList)
            {
                lvTables.Items.Add(tableInfo.TableName);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimizeScreen_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void frmCodeGen_Load(object sender, EventArgs e)
        {
            LoadScreen();
            _FillDatabaseCombobox();
        }

        private void LoadScreen()
        {
            ShowLabelForMyDefinitions();
            DatabaseName = "";
            TableName = "";
            cbDatabases.Items.Clear();
            lvColumns.Items.Clear();
            lvTables.Items.Clear();
        }

        private void lvTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvTables.SelectedItems.Count > 0)
            {
                TableName = lvTables.SelectedItems[0].Text;
                LoadColumns();
            }
        }

        private void LoadColumns()
        {
            lvColumns.Items.Clear();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                ListViewItem item = new ListViewItem(columnInfo.ColumnName);

                item.SubItems.Add(columnInfo.DataType); 
                item.SubItems.Add(columnInfo.IsNullable ? "Yes" : "No"); 
                item.SubItems.Add(columnInfo.IsPrimaryKey ? "Yes" : "No"); 
                item.SubItems.Add(columnInfo.ReferencedTable ?? "None"); 

                lvColumns.Items.Add(item); 
            }
        }

        void ShowLabelForMyDefinitions()
        {
            lblCode.Visible = true;
        }
        void HideLabelForMyDefinitions()
        {
            lblCode.Visible = false;
        }

        private bool IsDatabaseAndTableNameValid()
        {
            if (string.IsNullOrEmpty(DatabaseName) || string.IsNullOrEmpty(TableName))
            {
                ShowMessageBox("You haven't chosen a Database Name or Table Name. Please check again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool IsDatabaseNameValid()
        {
            if (string.IsNullOrEmpty(DatabaseName))
            {
                ShowMessageBox("You haven't chosen a Database Name. Please check again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btnGenerateBusinessLayer_Click(object sender, EventArgs e)
        {
            if (!IsDatabaseAndTableNameValid())
            {
                return;
            }

            HideLabelForMyDefinitions();
            rtbGeneratedCode.Text = new clsClassGen(DatabaseName, TableName).Generate().ToString();
        }

        private void btnGenerateDataAccessLayer_Click(object sender, EventArgs e)
        {
            if (!IsDatabaseAndTableNameValid())
            {
                return;
            }

            HideLabelForMyDefinitions();
            rtbGeneratedCode.Text = new clsClassDataGen(DatabaseName, TableName).Generate().ToString();
        }

        private void btnGenerateDataAccessSettings_Click(object sender, EventArgs e)
        {
            if (!IsDatabaseNameValid())
            {
                return;
            }

            HideLabelForMyDefinitions();
            rtbGeneratedCode.Text = new clsClassDataAccessSettingsGen(DatabaseName).Generate().ToString();
        }

        private void btnAdvancedGenerating_Click(object sender, EventArgs e)
        {
            if (!IsDatabaseNameValid())
            {
                return;
            }

            frmAdvancedGenerating advancedGenerating = new frmAdvancedGenerating();
            advancedGenerating.ShowDialog();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(rtbGeneratedCode.Text))
            {
                Clipboard.SetText(rtbGeneratedCode.Text);
                ShowMessageBox("Ok, you have copied all the code.", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                ShowMessageBox("You don't have any code to copy.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSelectMethods_Click(object sender, EventArgs e)
        {
            if (!IsDatabaseNameValid())
            {
                return;
            }

            frmSelectFunctions advancedFunctionGeneration = new frmSelectFunctions();
            advancedFunctionGeneration.ShowDialog();
        }
        private void Panel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }
    }
}
