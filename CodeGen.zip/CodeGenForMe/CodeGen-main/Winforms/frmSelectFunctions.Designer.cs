﻿namespace CodeGen
{
    partial class frmSelectFunctions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSelectFunctions));
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMinimizeScreen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lblInfoForTheForm = new System.Windows.Forms.Label();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chbDelete = new System.Windows.Forms.CheckBox();
            this.chbIsDataFoundByID = new System.Windows.Forms.CheckBox();
            this.chbAddNewUpdate = new System.Windows.Forms.CheckBox();
            this.chbFindDataByID = new System.Windows.Forms.CheckBox();
            this.chbGetAllData = new System.Windows.Forms.CheckBox();
            this.btnAdvancedGenerating = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHeader
            // 
            this.pnlHeader.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlHeader.Controls.Add(this.pictureBox1);
            this.pnlHeader.Controls.Add(this.label2);
            this.pnlHeader.Controls.Add(this.btnMinimizeScreen);
            this.pnlHeader.Controls.Add(this.btnClose);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(520, 56);
            this.pnlHeader.TabIndex = 25;
            this.pnlHeader.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pictureBox1.Image = global::CodeGen.Properties.Resources.Select_functions;
            this.pictureBox1.Location = new System.Drawing.Point(10, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(159, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 32);
            this.label2.TabIndex = 25;
            this.label2.Text = "Select Functions";
            this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            // 
            // btnMinimizeScreen
            // 
            this.btnMinimizeScreen.BackgroundImage = global::CodeGen.Properties.Resources.minus;
            this.btnMinimizeScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMinimizeScreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizeScreen.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnMinimizeScreen.Location = new System.Drawing.Point(392, 3);
            this.btnMinimizeScreen.Name = "btnMinimizeScreen";
            this.btnMinimizeScreen.Size = new System.Drawing.Size(50, 50);
            this.btnMinimizeScreen.TabIndex = 5;
            this.btnMinimizeScreen.UseVisualStyleBackColor = true;
            this.btnMinimizeScreen.Click += new System.EventHandler(this.btnMinimizeScreen_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImage = global::CodeGen.Properties.Resources.remove;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnClose.Location = new System.Drawing.Point(459, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(50, 50);
            this.btnClose.TabIndex = 4;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lblInfoForTheForm
            // 
            this.lblInfoForTheForm.AutoSize = true;
            this.lblInfoForTheForm.Font = new System.Drawing.Font("Segoe UI Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblInfoForTheForm.Location = new System.Drawing.Point(94, 73);
            this.lblInfoForTheForm.Name = "lblInfoForTheForm";
            this.lblInfoForTheForm.Size = new System.Drawing.Size(320, 25);
            this.lblInfoForTheForm.TabIndex = 26;
            this.lblInfoForTheForm.Text = "Select the functions you want to use:";
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSelectAll.Location = new System.Drawing.Point(24, 114);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(113, 33);
            this.btnSelectAll.TabIndex = 27;
            this.btnSelectAll.Text = "Select All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chbDelete);
            this.panel2.Controls.Add(this.chbIsDataFoundByID);
            this.panel2.Controls.Add(this.chbAddNewUpdate);
            this.panel2.Controls.Add(this.chbFindDataByID);
            this.panel2.Controls.Add(this.chbGetAllData);
            this.panel2.Location = new System.Drawing.Point(28, 157);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(464, 132);
            this.panel2.TabIndex = 28;
            // 
            // chbDelete
            // 
            this.chbDelete.AutoSize = true;
            this.chbDelete.Location = new System.Drawing.Point(271, 82);
            this.chbDelete.Name = "chbDelete";
            this.chbDelete.Size = new System.Drawing.Size(69, 20);
            this.chbDelete.TabIndex = 4;
            this.chbDelete.Tag = "16";
            this.chbDelete.Text = "Delete";
            this.chbDelete.UseVisualStyleBackColor = true;
            this.chbDelete.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // chbIsDataFoundByID
            // 
            this.chbIsDataFoundByID.AutoSize = true;
            this.chbIsDataFoundByID.Location = new System.Drawing.Point(70, 82);
            this.chbIsDataFoundByID.Name = "chbIsDataFoundByID";
            this.chbIsDataFoundByID.Size = new System.Drawing.Size(147, 20);
            this.chbIsDataFoundByID.TabIndex = 3;
            this.chbIsDataFoundByID.Tag = "8";
            this.chbIsDataFoundByID.Text = "Is Data Found By ID";
            this.chbIsDataFoundByID.UseVisualStyleBackColor = true;
            this.chbIsDataFoundByID.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // chbAddNewUpdate
            // 
            this.chbAddNewUpdate.AutoSize = true;
            this.chbAddNewUpdate.Location = new System.Drawing.Point(329, 17);
            this.chbAddNewUpdate.Name = "chbAddNewUpdate";
            this.chbAddNewUpdate.Size = new System.Drawing.Size(133, 20);
            this.chbAddNewUpdate.TabIndex = 2;
            this.chbAddNewUpdate.Tag = "4";
            this.chbAddNewUpdate.Text = "Add New/Update";
            this.chbAddNewUpdate.UseVisualStyleBackColor = true;
            this.chbAddNewUpdate.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // chbFindDataByID
            // 
            this.chbFindDataByID.AutoSize = true;
            this.chbFindDataByID.Location = new System.Drawing.Point(148, 17);
            this.chbFindDataByID.Name = "chbFindDataByID";
            this.chbFindDataByID.Size = new System.Drawing.Size(147, 20);
            this.chbFindDataByID.TabIndex = 1;
            this.chbFindDataByID.Tag = "2";
            this.chbFindDataByID.Text = "Get/Find Data By ID";
            this.chbFindDataByID.UseVisualStyleBackColor = true;
            this.chbFindDataByID.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // chbGetAllData
            // 
            this.chbGetAllData.AutoSize = true;
            this.chbGetAllData.Location = new System.Drawing.Point(14, 17);
            this.chbGetAllData.Name = "chbGetAllData";
            this.chbGetAllData.Size = new System.Drawing.Size(100, 20);
            this.chbGetAllData.TabIndex = 0;
            this.chbGetAllData.Tag = "1";
            this.chbGetAllData.Text = "Get All Data";
            this.chbGetAllData.UseVisualStyleBackColor = true;
            this.chbGetAllData.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // btnAdvancedGenerating
            // 
            this.btnAdvancedGenerating.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAdvancedGenerating.Location = new System.Drawing.Point(320, 305);
            this.btnAdvancedGenerating.Name = "btnAdvancedGenerating";
            this.btnAdvancedGenerating.Size = new System.Drawing.Size(172, 36);
            this.btnAdvancedGenerating.TabIndex = 29;
            this.btnAdvancedGenerating.Text = "Advanced Generating";
            this.btnAdvancedGenerating.UseVisualStyleBackColor = true;
            this.btnAdvancedGenerating.Click += new System.EventHandler(this.btnAdvancedGenerating_Click);
            // 
            // frmSelectFunctions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(520, 357);
            this.Controls.Add(this.btnAdvancedGenerating);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnSelectAll);
            this.Controls.Add(this.lblInfoForTheForm);
            this.Controls.Add(this.pnlHeader);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSelectFunctions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select Functions";
            this.Load += new System.EventHandler(this.frmSelectFunctions_Load);
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMinimizeScreen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblInfoForTheForm;
        private System.Windows.Forms.Button btnSelectAll;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chbIsDataFoundByID;
        private System.Windows.Forms.CheckBox chbAddNewUpdate;
        private System.Windows.Forms.CheckBox chbFindDataByID;
        private System.Windows.Forms.CheckBox chbGetAllData;
        private System.Windows.Forms.CheckBox chbDelete;
        private System.Windows.Forms.Button btnAdvancedGenerating;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}