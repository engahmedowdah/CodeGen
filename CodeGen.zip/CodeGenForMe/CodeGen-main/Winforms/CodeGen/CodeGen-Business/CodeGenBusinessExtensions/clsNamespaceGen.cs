﻿using System;
using System.Text;
using System.Data.SqlClient;
using CodeGen.Interfaces;
using CodeGen.Global;
namespace CodeGen_Business.Business
{
    internal class clsNamespaceGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        internal clsNamespaceGen(string databaseName)
        {
            DatabaseName = databaseName;
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"namespace {DatabaseName}_Business");
            return sb;
        }
    }
}
