﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalGen.Business;

namespace CodeGen_Business.Business
{
    internal class clsPropertiesGen : IGenerate
    {
        public string TableName { get; private set; }
        public string DatabaseName { get; private set; }
        public clsTable TableInfo { get; private set; }
        internal clsPropertiesGen( string databaseName, string tableName)
        {
            TableName = tableName;
            DatabaseName = databaseName;
            TableInfo = clsTable.GetTableByName(databaseName, tableName);
        }
        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            foreach(clsColumn columnInfo in TableInfo.ColumnsList)
            {
                sb.AppendLine($"{GenerateProperty(columnInfo)}");
            }

            sb.AppendLine($"\n{clsUtil.CreateTabs(2)}public string Error = \"\";\n");
          
            return sb;
        }
        public StringBuilder GenerateProperty(clsColumn columnInfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(2)}public {columnInfo.DataType} {columnInfo.ColumnName} {{get; set;}}");
            if (columnInfo.IsForeignKey)
            {
                sb.AppendLine($"{GenerateLinkedPropertyWithClass(columnInfo)}");
            }
            return sb;
        }

        public StringBuilder GenerateLinkedPropertyWithClass(clsColumn columnInfo)
        {
            StringBuilder sb = new StringBuilder();
            clsTable LinkedTableInfo = clsTable.GetTableByName(columnInfo.DatabaseName, columnInfo.ReferencedTable);
            clsGlobalBusinessLayer globalBusinessLayer = new clsGlobalBusinessLayer(LinkedTableInfo.DatabaseName, LinkedTableInfo.TableName, clsGlobalBusinessLayer.enMode.GetDataByID);
            sb.AppendLine($"{clsUtil.CreateTabs(2)}public {LinkedTableInfo.BusinessClassName} {LinkedTableInfo.SingularTableName}Info");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");
            sb.AppendLine($"{clsUtil.CreateTabs(3)}return {globalBusinessLayer.FunctionName}({globalBusinessLayer.CreateSignatureWithoutTypes()});");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
