﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalGen.Business;
namespace CodeGen_Business.Business
{
    internal class clsGetDataByIDGen : IGenerate
    {
        public string TableName { get; private set; }
        public string DatabaseName { get; private set; }
        internal clsGetDataByIDGen(string databaseName, string tableName)
        {
            TableName = tableName;
            DatabaseName = databaseName;
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            clsGlobalBusinessLayer globalBusinessLayer = new clsGlobalBusinessLayer(DatabaseName, TableName, clsGlobalBusinessLayer.enMode.GetDataByID);
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{globalBusinessLayer.GetFunctionInfo()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");
            sb.AppendLine($"{globalBusinessLayer.CreateReturnText()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
