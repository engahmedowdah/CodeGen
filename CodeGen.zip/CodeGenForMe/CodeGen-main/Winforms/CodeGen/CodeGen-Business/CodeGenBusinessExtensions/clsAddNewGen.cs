﻿using System;
using System.Text;
using System.Data.SqlClient;
using CodeGen.Interfaces;
using GlobalGen.Business;
using CodeGen.Global;

namespace CodeGen_Business.Business
{
    internal class clsAddNewGen : IGenerate
    {
        public string TableName {  get; private set; }
        public string DatabaseName {  get; private set; }
        internal clsAddNewGen(string databaseName, string tableName)
        {
            TableName = tableName;
            DatabaseName = databaseName;
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            clsGlobalBusinessLayer globalBusinessLayer = new clsGlobalBusinessLayer(DatabaseName,TableName,clsGlobalBusinessLayer.enMode.AddNew);
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{globalBusinessLayer.GetFunctionInfo()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");
            sb.AppendLine($"{globalBusinessLayer.CreateReturnText()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
