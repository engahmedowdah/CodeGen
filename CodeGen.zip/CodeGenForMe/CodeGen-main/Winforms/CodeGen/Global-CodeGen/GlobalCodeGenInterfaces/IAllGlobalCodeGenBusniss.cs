﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeGen.CodeGen.CodeGen_Business.CodeGenBusinessInterfaces;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces
{
    internal interface IAllGlobalCodeGenBusniss : IGenClassConstructor, IGenClassDefaultConstructor, IGenFunctionSignature
    {
    }
}
