﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces
{
    internal interface IGenFunctionSignature
    {
        StringBuilder GenFunctionSignature();
    }
}
