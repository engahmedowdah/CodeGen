﻿using CodeGen.CodeGen.CodeGen_Business.CodeGenBusinessExtensions;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenExtensions
{
    internal class clsAllGlobalCodeGenBusniss : IAllGlobalCodeGenBusniss
    {
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID, Save, Class };
        private enMode _Mode = enMode.AddNew;
        
        private string TableName { get; set; }
        private string DatabaseName {  get; set; }
        private string SingularTableName 
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        public clsAllGlobalCodeGenBusniss(string DatabaseName, string TableName, enMode mode)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
            this._Mode = mode;
        }
        public clsAllGlobalCodeGenBusniss(string DatabaseName, string TableName)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
        }
        public StringBuilder GenClassConstructor()
        {
            StringBuilder sb = new StringBuilder();
            clsGenClassConstructor genClassConstructor = new clsGenClassConstructor(DatabaseName,TableName);
            sb = genClassConstructor.GenClassConstructor();
            return sb;
        }

        public StringBuilder GenClassDefaultConstructor()
        {
            StringBuilder sb = new StringBuilder();
            clsGenClassDefaultConstructor genClassDefaultConstructor = new clsGenClassDefaultConstructor(DatabaseName, TableName);
            sb = genClassDefaultConstructor.GenClassDefaultConstructor();
            return sb;
        }
        public StringBuilder GenFunctionSignature()
        {
            StringBuilder sb = new StringBuilder();
            clsGenFunctionSignature genFunctionSignature = new clsGenFunctionSignature(DatabaseName, TableName, (clsGenFunctionSignature.enMode)(_Mode)); 
            sb = genFunctionSignature.GenFunctionSignature();
            return sb;
        }

        public StringBuilder NamespaceGen()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{this.DatabaseName}_BusnissLayer.{this.SingularTableName}");
            return sb;
        }
    }
}
