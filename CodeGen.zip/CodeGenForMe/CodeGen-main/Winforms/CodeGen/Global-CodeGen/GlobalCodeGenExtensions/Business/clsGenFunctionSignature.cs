﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss
{
    public class clsGenFunctionSignature : IGenFunctionSignature
    {
        
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID, Save };
        private enMode _Mode = enMode.AddNew;
        public string FunctionName { get; set; }
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo = new clsTable();
        private string SinglerTableName
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        private string ClassName 
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        public clsGenFunctionSignature(string DatabaseName, string TableName, enMode mode)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this._Mode = mode;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
        }
        public StringBuilder GenFunctionSignature()
        {
            StringBuilder sb = new StringBuilder();
            switch(_Mode)
            {
                case enMode.AddNew:
                    sb = GenFunctionSignatureForAddNew();
                    break;
                case enMode.Update:
                    sb = GenFunctionSignatureForUpdate();
                    break;
                case enMode.Delete:
                    sb = GenFunctionSignatureForDelete();
                    break;
                case enMode.GetAllData:
                    sb = GenFunctionSignatureForGetAllData();
                    break;
               case enMode.GetDataByID:
                    sb = GenFunctionSignatureForGetDataByID();
                    break;
                case enMode.IsFoundByID:
                    sb = GenFunctionSignatureForIsFoundByID();
                    break;
            }
            return sb;
        }
        private StringBuilder GenFunctionSignatureForAddNew()
        {
            StringBuilder sb = new StringBuilder();
            FunctionName = $"AddNew";
            sb.Append($"private bool AddNew({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.AddNew).GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForUpdate()
        {
            StringBuilder sb = new StringBuilder();
            FunctionName = $"Update";
            sb.Append($"private bool Update({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.Update).GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForGetAllData()
        {
            StringBuilder sb = new StringBuilder();
            FunctionName = $"GetAll{TableName}";
            sb.Append($"public static DataTable GetAll{TableName}({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.GetAllData).GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForGetDataByID()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static {this.ClassName} Get{this.SinglerTableName}ByID({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.GetDataByID).GenParameterList()})");
            FunctionName = $"Get{this.SinglerTableName}ByID";
            return sb;
        }
        private StringBuilder GenFunctionSignatureForIsFoundByID()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static bool Is{this.SinglerTableName}FoundByID({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.IsFoundByID).GenParameterList()})");
            this.FunctionName = $"Is{this.SinglerTableName}FoundByID";
            return sb;
        }
        private StringBuilder GenFunctionSignatureForDelete()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static bool Delete({new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.Delete).GenParameterList()})");
            this.FunctionName = "Delete";  
            return sb;
        }

    }
}
