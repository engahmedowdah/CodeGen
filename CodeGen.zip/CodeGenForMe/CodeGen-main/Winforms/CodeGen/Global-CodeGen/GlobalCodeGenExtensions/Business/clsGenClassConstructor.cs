﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenExtensions;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss
{
    public class clsGenClassConstructor : IGenClassConstructor
    {
        
        private string DatabaseName {  get; set; }
        private string TableName {  get; set; }
        private clsTable tableInfo = new clsTable();
        private string ClassName 
        {
            get
            {
                return "cls"+this.TableName;
            }
        }
        public clsGenClassConstructor(string DatabaseName,string TableName) 
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
        }
        public StringBuilder GenClassConstructor()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"private {this.ClassName}({GetParameters()})");
            sb.AppendLine("{");
            sb.Append($"{GetParametersInClass()}");
            sb.AppendLine("}");
            return sb;
        }
        private StringBuilder GetParameters()
        {
            StringBuilder sb = new StringBuilder();
            int Index = 0;
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                Index++;
                sb.Append($"{column.DataType} {column.ColumnName}, ");
                if (Index % 5 == 0)
                    sb.AppendLine($"{Global.clsUtil.Tabs(4)}");
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }

            return sb;
        }
        private StringBuilder GetParametersInClass()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                sb.AppendLine($"this.{column.ColumnName} = {column.ColumnName};");
            }
            return sb;
        }
    }
}
