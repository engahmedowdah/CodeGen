﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenExtensions.Business
{
    internal class clsParametersInFunctionGen : IParametersInFunctionGen
    {
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID, Save};
        private enMode _Mode = enMode.AddNew;
        private List<string>_FunctionNames = new List<string>()
        {
            "AddNew",
            "Update",
            "Delete",
            "GetDataByID",
            "FindDataByID",
            "IsFoundByID",
            "GetAllData"
        };
        private string TableName { get; set; }
        private string DatabaseName { get; set; }
        private string SingularTableName
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        private clsTable tableInfo
        {
            get
            {
                return clsTable.GetTableByName(DatabaseName, TableName);
            }
        }
        public clsParametersInFunctionGen(string DatabaseName, string TableName, enMode mode)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
            this._Mode = mode;
        }
        public StringBuilder ParametersInFunctionGen()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    sb = clsParametersInAddNewMethodGen.ParametersInAddNewMethodGen();
                    break;
                case enMode.Update:
                    sb = clsParametersInUpdateMethodGen.ParametersInUpdateMethodGen();
                    break;
                case enMode.Delete:
                    sb = clsParametersInDeleteMethodGen.ParametersInDeleteMethodGen();
                    break;
                case enMode.GetDataByID:
                    sb = clsParametersInGetDataByIDMethod.ParametersInGetDataByIDMethod();
                    break;
                case enMode.IsFoundByID:
                    sb = clsParametersInIsDataFoundByIDGen.ParametersInIsDataFoundByIDGen();
                    break;
                case enMode.GetAllData:
                    sb = clsParametersInGetAllDataMethodGen.ParametersInGetAllDataMethodGen();  
                    break;
            }
            return sb;
        }

        internal class clsParametersInAddNewMethodGen
        {
            public static StringBuilder ParametersInAddNewMethodGen()
            {
                StringBuilder sb = new StringBuilder();
                //foreach(clsColumn column )
                //{

                //}
                sb.AppendLine("return this");
                return sb;
            }
        }
        internal class clsParametersInUpdateMethodGen
        {
            public static StringBuilder ParametersInUpdateMethodGen()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
        internal class clsParametersInDeleteMethodGen
        {
            public static StringBuilder ParametersInDeleteMethodGen()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
        internal class clsParametersInGetAllDataMethodGen
        {
            public static StringBuilder ParametersInGetAllDataMethodGen()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
        internal class clsParametersInGetDataByIDMethod
        {
            public static StringBuilder ParametersInGetDataByIDMethod()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
        internal class clsParametersInSaveMethodGen
        {
            public static StringBuilder ParametersInSaveMethodGen()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
        internal class clsParametersInIsDataFoundByIDGen
        {
            public static StringBuilder ParametersInIsDataFoundByIDGen()
            {
                StringBuilder sb = new StringBuilder();

                return sb;
            }
        }
    }
}
