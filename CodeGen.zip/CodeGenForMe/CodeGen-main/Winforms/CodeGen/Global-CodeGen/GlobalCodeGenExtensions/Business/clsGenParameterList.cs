﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen_Business;
using System;
using System.Text;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss
{
    internal class clsGenParameterList : IGenParameterList
    {
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID, Save, Class };
        private enMode _Mode;
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo;

        public clsGenParameterList(string DatabaseName, string TableName, enMode mode)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
            this._Mode = mode;
        }

        public StringBuilder GenParameterList()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    return GenParameterListForEntity();
                case enMode.Update:
                    return GenParameterListForEntity();
                case enMode.Delete:
                    return GenParameterListForPrimaryKeys();
                case enMode.GetAllData:
                    return new StringBuilder(); 
                case enMode.GetDataByID:
                    return GenParameterListForPrimaryKeys();
                case enMode.Save:
                    return new StringBuilder();
                case enMode.Class:
                    return GenPropertiesForClass();
                default:
                    return new StringBuilder();
            }
        }

        private StringBuilder GenParameterListForEntity()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (!column.IsPrimaryKey) 
                {
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }

            return sb;
        }

        private StringBuilder GenParameterListForPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }

            return sb;
        }

        private StringBuilder GenPropertiesForClass()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                { 
                    sb.AppendLine($"public {column.DataType} {column.ColumnName} {{ get; set; }}");
                } 
            }
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (!column.IsPrimaryKey && column.IsForeignKey)
                {
                    sb.AppendLine($"public {column.DataType} {column.ColumnName} {{ get; set; }}");
                    GenPropertyForLinkedClass(column);
                }
            }
            return sb;
        }

        private StringBuilder GenPropertyForLinkedClass(clsColumn column)
        {
            StringBuilder sb = new StringBuilder();
            if (column.IsForeignKey)
            {
                clsGenFunctionSignature functionSignature = new clsGenFunctionSignature(column.DatabaseName, column.TableName, clsGenFunctionSignature.enMode.FindDataByID);
                sb.AppendLine($"public cls{column.ReferencedTable} {column.ReferencedTable.ToLower()} {{");
                sb.AppendLine("get {");
                sb.AppendLine($"return cls{column.ReferencedTable}.{functionSignature.FunctionName}({GetPrimaryKeyParameters()});");
                sb.AppendLine("}}");
            }
            return sb;
        }

        private string GetPrimaryKeyParameters()
        {
            StringBuilder parameters = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    parameters.Append($"{column.ColumnName}, "); 
                }
            }

            if (parameters.Length > 0)
            {
                parameters.Remove(parameters.Length - 2, 2); 
            }

            return parameters.ToString();
        }
    }
}