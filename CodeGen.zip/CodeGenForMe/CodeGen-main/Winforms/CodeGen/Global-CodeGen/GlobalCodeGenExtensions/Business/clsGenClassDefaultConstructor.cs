﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss
{
    internal class clsGenClassDefaultConstructor : IGenClassDefaultConstructor
    {
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo = new clsTable();
        private string ClassName
        {
            get
            {
                return "cls" + this.TableName;
            }
        }
        public clsGenClassDefaultConstructor(string DatabaseName, string TableName)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
        }
        public StringBuilder GenClassDefaultConstructor()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"public {this.ClassName}()");
            sb.AppendLine("{");
            sb.Append($"{GetParametersInClass()}");
            sb.Append("}");
            return sb;
        }
        private StringBuilder GetParametersInClass()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                sb.AppendLine($"this.{column.ColumnName} = {Global.clsUtil.DefaultValue(column.DataType)};");
            }
            return sb;
        }
    }
}
