﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.DataAccess
{
    internal class clsGenParameterListData : IGenParameterList
    {
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID };
        private enMode _Mode = enMode.AddNew;
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo = new clsTable();
        public clsGenParameterListData(string DatabaseName, string TableName, enMode mode = enMode.AddNew)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
            this._Mode = mode;
        }
        public StringBuilder GenParameterList()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    sb = GenParameterListForAddNew();
                    break;
                case enMode.Update:
                    sb = GenParameterListForUpdate();
                    break;
                case enMode.Delete:
                    sb = GenParameterListForDelete();
                    break;
                case enMode.GetAllData:
                    sb = GenParameterListGetAllData();
                    break;
                case enMode.GetDataByID:
                    sb = GenParameterListGetDataByID();
                    break;
            }
            return sb;
        }
        private StringBuilder GenParameterListForAddNew()
        {
            StringBuilder sb = new StringBuilder();
            int Index = 0;
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    Index++;
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                    if (Index % 5 == 0)
                        sb.AppendLine();
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        private StringBuilder GenParameterListForUpdate()
        {
            StringBuilder sb = new StringBuilder();
            int Index = 0;
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    Index++;
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                    if (Index % 5 == 0)
                        sb.AppendLine();
                }
            }
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    Index++;
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                    if (Index % 5 == 0)
                        sb.AppendLine();
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        private StringBuilder GenParameterListGetAllData()
        {
            StringBuilder sb = new StringBuilder();
            return sb;
        }
        private StringBuilder GenParameterListGetDataByID()
        {
            StringBuilder sb = new StringBuilder();
            int Index = 0;
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    Index++;
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                    if (Index % 5 == 0)
                        sb.AppendLine();
                }
            }
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    Index++;
                    sb.Append($"ref {column.DataType} {column.ColumnName}, ");
                    if (Index % 5 == 0)
                        sb.AppendLine();
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        private StringBuilder GenFunctionSignatureForIsFoundByID()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }

            return sb;
        }
        private StringBuilder GenParameterListForDelete()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in tableInfo.ColumnsList)
            {
                if (column.IsPrimaryKey)
                {
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
                }
            }

            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }

            return sb;
        }
    }
}
