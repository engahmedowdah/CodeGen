﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenExtensions.DataAccess
{
    internal class clsParametersInFunctiongen : IParametersInFunctionGen
    {
        public StringBuilder ParametersInFunctionGen()
        {
            throw new NotImplementedException();
        }
    }
}
