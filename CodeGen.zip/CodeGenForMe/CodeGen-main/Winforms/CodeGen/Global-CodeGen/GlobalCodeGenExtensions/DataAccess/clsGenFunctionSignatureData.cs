﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.Busniss;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.DataAccess
{
    internal class clsGenFunctionSignatureData : IGenFunctionSignature
    {
        private clsGenParameterList genParameterList { get; set; }
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID };
        private enMode _Mode = enMode.AddNew;
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo = new clsTable();
        private string SinglerTableName
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        private string ClassName
        {
            get
            {
                return clsSingularizer.ConvertToSingular(TableName);
            }
        }
        public clsGenFunctionSignatureData(string DatabaseName, string TableName, enMode mode)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this._Mode = mode;
            this.tableInfo = clsTable.FindTableInfoByName(DatabaseName, TableName);
        }
        public StringBuilder GenFunctionSignature()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    sb = GenFunctionSignatureForAddNew();
                    break;
                case enMode.Update:
                    sb = GenFunctionSignatureForUpdate();
                    break;
                case enMode.Delete:
                    sb = GenFunctionSignatureForDelete();
                    break;
                case enMode.GetAllData:
                    sb = GenFunctionSignatureForGetAllData();
                    break;
                case enMode.GetDataByID:
                    sb = GenFunctionSignatureForFindDataByID();
                    break;
                case enMode.IsFoundByID:
                    sb = GenFunctionSignatureForIsFoundByID();
                    break;
            }
            return sb;
        }
        private StringBuilder GenFunctionSignatureForAddNew()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.AddNew);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static bool AddNew({genParameterList.GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForUpdate()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.Update);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static Update({genParameterList.GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForGetAllData()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.GetAllData);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static DataTable GetAll{TableName}({genParameterList.GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForFindDataByID()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.GetDataByID);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static {this.ClassName} Find{this.SinglerTableName}ByID({genParameterList.GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForIsFoundByID()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.IsFoundByID);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static bool Is{this.SinglerTableName}FoundByID({genParameterList.GenParameterList()})");
            return sb;
        }
        private StringBuilder GenFunctionSignatureForDelete()
        {
            this.genParameterList = new clsGenParameterList(DatabaseName, TableName, clsGenParameterList.enMode.Delete);
            StringBuilder sb = new StringBuilder();
            sb.Append($"public static bool Delete({genParameterList.GenParameterList()})");
            return sb;
        }
    }
}
