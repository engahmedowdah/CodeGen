﻿using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenDataAccessExtensions.DataAccess;
using CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenInterfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.CodeGen.Global_CodeGen.GlobalCodeGenExtensions
{
    public class clsAllGlobalCodeGenDataAccess : IAllGlobalCodeGenDataAccess
    {
        public enum enMode { AddNew, Update, Delete, FindDataByID, GetAllData, IsFoundByID, GetDataByID };
        private enMode _Mode = enMode.AddNew;
        private string DatabaseName { get; set; }
        private string TableName { get; set; }
        private clsTable tableInfo = new clsTable();
        public clsAllGlobalCodeGenDataAccess(string DatabaseName, string TableName, enMode mode = enMode.AddNew)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this._Mode = mode;
        }
        public StringBuilder GenFunctionSignature()
        {
            StringBuilder sb = new StringBuilder();
            clsGenFunctionSignatureData genFunctionSignatureData = new clsGenFunctionSignatureData(DatabaseName, TableName, (clsGenFunctionSignatureData.enMode)(_Mode));
            sb = genFunctionSignatureData.GenFunctionSignature();
            return sb;
        }

        public StringBuilder GenNamespaces()
        {
            throw new NotImplementedException();
        }
    }
}
