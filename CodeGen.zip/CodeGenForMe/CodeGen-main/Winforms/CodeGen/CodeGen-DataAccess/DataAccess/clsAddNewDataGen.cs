﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalGen.DataAccess;

namespace CodeGen_DataAccess.DataAccess
{
    internal class clsAddNewDataGen : IGenerate
    {
        private string DatabaseName {  get; set; }
        private string TableName {  get; set; }
        private clsTable tableInfo {  get; set; }
        internal clsAddNewDataGen(string DatabaseName, string TableName)
        {
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
            this.tableInfo = clsTable.GetTableByName(DatabaseName,TableName);
        }
        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            clsGlobalDataAccessLayer globalDataAccessLayer = new clsGlobalDataAccessLayer(DatabaseName, TableName, clsGlobalDataAccessLayer.enMode.AddNew);
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{globalDataAccessLayer.GetFunctionInfo()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");
            sb.AppendLine($"{globalDataAccessLayer.CreateCodeInsideFunction()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
