﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalGen.DataAccess;

namespace CodeGen_DataAccess.DataAccess
{
    internal class clsUpdateDataGen : IGenerate
    {
        public string TableName { get; private set; }
        public string DatabaseName { get; private set; }
        public clsTable TableInfo { get; private set; }
        internal clsUpdateDataGen(string databaseName, string tableName)
        {
            TableName = tableName;
            DatabaseName = databaseName;
            TableInfo = clsTable.GetTableByName(databaseName, tableName);
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            clsGlobalDataAccessLayer globalDataAccessLayer = new clsGlobalDataAccessLayer(DatabaseName,TableName,clsGlobalDataAccessLayer.enMode.Update);
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{globalDataAccessLayer.GetFunctionInfo()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");
            sb.AppendLine($"{globalDataAccessLayer.CreateCodeInsideFunction()}");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
