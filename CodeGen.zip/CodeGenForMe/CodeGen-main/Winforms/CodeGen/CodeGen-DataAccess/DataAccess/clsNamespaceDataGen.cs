﻿using System;
using System.Text;
using System.Data.SqlClient;
using CodeGen_DataAccess;
using System.Collections.Generic;
using CodeGen_Business;
using CodeGen.Global;
using CodeGen.Interfaces;

namespace CodeGen_DataAccess.DataAccess
{ 
    internal class clsNamespaceDataGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        internal clsNamespaceDataGen(string databaseName)
        {
            DatabaseName = databaseName;
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"namespace {DatabaseName}_DataAccess");
            return sb;
        }
    }
}
