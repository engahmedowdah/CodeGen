﻿using System;
using System.Text;
using System.Data.SqlClient;
using CodeGen_DataAccess;
using System.Collections.Generic;
using CodeGen_Business;
using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business.Business;

namespace CodeGen_DataAccess.DataAccess
{
    public class clsClassDataGen : IGenerate
    {
        public string TableName { get; private set; }
        public string DatabaseName { get; private set; }
        public int TableID { get; private set; }
        public clsTable TableInfo { get; private set; }
        public int Permissions { get; private set; }
        public clsClassDataGen(string DatabaseName, string TableName)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
            this.TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            this.TableID = TableInfo.TableID;
        }
        public clsClassDataGen(string DatabaseName, int TableID)
        {
            this.TableID = TableID;
            this.DatabaseName = DatabaseName;
            this.TableInfo = clsTable.GetTableByID(DatabaseName, TableID);
            this.TableName = TableInfo.TableName;
        }

        public StringBuilder Generate()
        {
            if (clsGlobal.Permissions == -1)
            {
                return GetAllFunctions();
            }
            else
            {
                return GetAllSelectedFunctions();
            }
        }

        private StringBuilder GetAllFunctions()
        {
            List<IGenerate> AllFunctions = new List<IGenerate>();

            AllFunctions.Add(new clsGetAllDataDataGen(DatabaseName, TableName));
            AllFunctions.Add(new clsFindDataByIDDataGen(DatabaseName, TableName));
            AllFunctions.Add(new clsIsDataFoundByIDDataGen(DatabaseName, TableName));
            AllFunctions.Add(new clsAddNewDataGen(DatabaseName, TableName));
            AllFunctions.Add(new clsUpdateDataGen(DatabaseName, TableName));
            AllFunctions.Add(new clsDeleteDataGen(DatabaseName, TableName));

            List<IGenerate> HeaderClass = new List<IGenerate>();
            HeaderClass.Add(new clsUsingNamespacesDataGen(DatabaseName));
            HeaderClass.Add(new clsNamespaceDataGen(DatabaseName));

            StringBuilder sb = new StringBuilder();
            foreach (IGenerate i in HeaderClass)
            {
                sb.Append(i.Generate());
            }
            sb.AppendLine("\n{\n");

            sb.AppendLine($"{clsUtil.CreateTabs(1)}public class {TableInfo.DataAccessClassName}");
            sb.AppendLine($"{clsUtil.CreateTabs(1)}{{");

            foreach (IGenerate i in AllFunctions)
            {
                sb.Append(i.Generate() + "\n");
            }

            sb.AppendLine($"\n{clsUtil.CreateTabs(1)}}}");

            sb.AppendLine("}");
            return sb;
        }

        private StringBuilder GetAllSelectedFunctions()
        {
            List<IGenerate> AllFunctions = new List<IGenerate>();
            if (CheckAccessPermission(clsGlobal.enPermissions.GetAllData))
            {
                AllFunctions.Add(new clsGetAllDataDataGen(DatabaseName, TableName));
            }
            if(CheckAccessPermission(clsGlobal.enPermissions.GetDataByID))
            {
                AllFunctions.Add(new clsFindDataByIDDataGen(DatabaseName, TableName));
            }
            if (CheckAccessPermission(clsGlobal.enPermissions.IsDataFoundByID))
            {
                AllFunctions.Add(new clsIsDataFoundByIDDataGen(DatabaseName, TableName));
            }
            if (CheckAccessPermission(clsGlobal.enPermissions.AddNewUpdate))
            {
                AllFunctions.Add(new clsAddNewDataGen(DatabaseName, TableName));
                AllFunctions.Add(new clsUpdateDataGen(DatabaseName, TableName));
            }
            if (CheckAccessPermission(clsGlobal.enPermissions.Delete))
            {
                AllFunctions.Add(new clsDeleteDataGen(DatabaseName, TableName));
            }

            List<IGenerate> HeaderClass = new List<IGenerate>();
            HeaderClass.Add(new clsUsingNamespacesDataGen(DatabaseName));
            HeaderClass.Add(new clsNamespaceDataGen(DatabaseName));

            StringBuilder sb = new StringBuilder();
            foreach (IGenerate i in HeaderClass)
            {
                sb.Append(i.Generate());
            }
            sb.AppendLine("\n{\n");

            sb.AppendLine($"{clsUtil.CreateTabs(1)}public class {TableInfo.BusinessClassName}");
            sb.AppendLine($"{clsUtil.CreateTabs(1)}{{");

            foreach (IGenerate i in AllFunctions)
            {

                sb.Append(i.Generate() + "\n");
            }

            sb.AppendLine($"\n{clsUtil.CreateTabs(1)}}}");

            sb.AppendLine("}");
            return sb;
        }

        static bool CheckAccessPermission(clsGlobal.enPermissions permissions)
        {
            if (clsGlobal.Permissions == (int)clsGlobal.enPermissions.All)
                return true;

            if (((int)permissions & clsGlobal.Permissions) == (int)permissions)
                return true;

            return false;
        }
    }
}
