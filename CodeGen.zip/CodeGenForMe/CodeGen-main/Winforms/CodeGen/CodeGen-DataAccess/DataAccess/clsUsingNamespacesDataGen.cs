﻿using System;
using System.Text;
using System.Data.SqlClient;
using CodeGen.Interfaces;
using System.Collections.Generic;
using CodeGen_Business;
using CodeGen.Global;

namespace CodeGen_DataAccess.DataAccess
{
    internal class clsUsingNamespacesDataGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        public clsDatabase DatabaseInfo { get; private set; }
        internal clsUsingNamespacesDataGen(string databaseName)
        {
            DatabaseName = databaseName;
            DatabaseInfo = clsDatabase.GetDatabaseByName(databaseName);
        }
        public StringBuilder Generate()
        {
            string[] Namespaces = { "System", "System.Text", "System.Data", "System.Data.SqlClient;", "System.Xml", "System.Collections.Generic", $"{DatabaseInfo.DatabaseNameWithDataAccessSettings}" };
            StringBuilder sb = new StringBuilder();
            foreach (string Namespace in Namespaces)
            {
                sb.AppendLine($"{_UsingNamespaceGen(Namespace)}");
            }
            return sb;
        }
        public string _UsingNamespaceGen(string Namespace)
        {
            return $"using {Namespace};";
        }
    }
}
