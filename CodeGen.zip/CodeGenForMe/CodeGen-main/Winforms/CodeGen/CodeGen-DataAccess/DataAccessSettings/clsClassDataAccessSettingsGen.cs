﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using System;
using System.Text;
using GlobalGen;
using System.Collections.Generic;
using CodeGen_DataAccess.DataAccessSettings;

namespace CodeGen_DataAccess.DataAccessSettings
{
    internal class clsClassDataAccessSettingsGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        public clsClassDataAccessSettingsGen(string databaseName)
        {
            this.DatabaseName = databaseName;
        }
        
        public StringBuilder Generate()
        {
            List<IGenerate> HeaderClass = new List<IGenerate>();
            HeaderClass.Add(new clsUsingNamespacesDataGen(DatabaseName));
            HeaderClass.Add(new clsNamespaceGen(DatabaseName));

            List<IGenerate> InsideClass = new List<IGenerate>();

            InsideClass.Add(new clsPropertiesGen(DatabaseName));

            StringBuilder sb = new StringBuilder();
            foreach (IGenerate gen in HeaderClass)
            {
                sb.Append(gen.Generate());
            }
            sb.AppendLine("\n{");



            sb.AppendLine($"{clsUtil.CreateTabs(1)}public class clsDataAccessSettings");
            sb.AppendLine($"{clsUtil.CreateTabs(1)}{{");
            foreach (IGenerate gen in InsideClass)
            {
                sb.Append(gen.Generate());
            }
            sb.AppendLine($"{clsUtil.CreateTabs(1)}}}");
            sb.AppendLine("}");

            return sb;
        }
    }
}
