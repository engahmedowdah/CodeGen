﻿using CodeGen_Business;
using System;
using System.Text;
using GlobalGen;
using CodeGen.Interfaces;
using CodeGen.Global;


namespace CodeGen_DataAccess.DataAccessSettings
{
    internal class clsPropertiesGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        internal clsPropertiesGen( string databaseName)
        {
            DatabaseName = databaseName;
        }
        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(2)}public static string ConnectionString");
            sb.AppendLine($"{clsUtil.CreateTabs(2)}{{");

            sb.AppendLine($"{clsUtil.CreateTabs(3)}get");
            sb.AppendLine($"{clsUtil.CreateTabs(3)}{{");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}return \"Data Source=.;Initial Catalog={DatabaseName};Integrated Security=True;TrustServerCertificate=True\";");
            sb.AppendLine($"{clsUtil.CreateTabs(3)}}}");

            sb.AppendLine($"{clsUtil.CreateTabs(2)}}}");
            return sb;
        }
    }
}
