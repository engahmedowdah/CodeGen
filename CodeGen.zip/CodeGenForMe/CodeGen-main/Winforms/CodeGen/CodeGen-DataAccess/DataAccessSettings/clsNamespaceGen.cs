﻿using CodeGen_Business;
using System;
using System.Text;
using GlobalGen;
using CodeGen.Interfaces;

namespace CodeGen_DataAccess.DataAccessSettings
{
    internal class clsNamespaceGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        clsDatabase DatabaseInfo;
        internal clsNamespaceGen(string databaseName)
        {
            DatabaseName = databaseName;
            this.DatabaseInfo = clsDatabase.GetDatabaseByName(databaseName);
        }

        public StringBuilder Generate()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"namespace {DatabaseInfo.DatabaseNameWithDataAccessSettings}");
            return sb;
        }
    }
}
