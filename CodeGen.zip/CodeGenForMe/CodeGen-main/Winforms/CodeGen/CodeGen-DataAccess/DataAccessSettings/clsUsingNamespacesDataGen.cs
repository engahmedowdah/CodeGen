﻿using CodeGen_Business;
using System;
using System.Text;
using GlobalGen;
using CodeGen.Interfaces;
using CodeGen.Global;


namespace CodeGen_DataAccess.DataAccessSettings
{
    internal class clsUsingNamespacesDataGen : IGenerate
    {
        public string DatabaseName { get; private set; }
        public clsDatabase DatabaseInfo { get; private set; }
        internal clsUsingNamespacesDataGen(string databaseName)
        {
            DatabaseName = databaseName;
            DatabaseInfo = clsDatabase.GetDatabaseByName(databaseName);
        }
        public StringBuilder Generate()
        {
            string[] Namespaces = { "System", "System.Text" };
            StringBuilder sb = new StringBuilder();
            foreach (string Namespace in Namespaces)
            {
                sb.AppendLine($"{_UsingNamespaceGen(Namespace)}");
            }
            return sb;
        }
        private string _UsingNamespaceGen(string Namespace)
        {
            return $"using {Namespace};";
        }
    }
}
