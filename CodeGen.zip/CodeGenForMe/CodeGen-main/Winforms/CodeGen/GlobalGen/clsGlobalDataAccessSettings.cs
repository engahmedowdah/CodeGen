﻿using CodeGen.Global;
using CodeGen.Interfaces;
using CodeGen_Business;
using CodeGen_DataAccess.DataAccessSettings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalGen.DataAccessSettings
{
    internal class clsGlobalDataAccessSettings : IGenerate
    {
        public string DatabaseName { get; set; }
        public clsGlobalDataAccessSettings(string DatabaseName)
        {
            this.DatabaseName = DatabaseName;
        }

        public StringBuilder Generate()
        {
            //Connection String for DatabaseInfo layer

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{new clsUsingNamespacesDataGen(DatabaseName).Generate()}");
            sb.AppendLine($"{new clsUsingNamespacesDataGen(DatabaseName).Generate()}");
            sb.AppendLine("{");
            sb.AppendLine($"{clsUtil.CreateTabs(1)}public class clsDataAccessSettings");
            sb.AppendLine($"{clsUtil.CreateTabs(1)}{{");

            sb.AppendLine($"{clsUtil.CreateTabs(1)}}}");
            sb.AppendLine("}");
            return sb;
        }
    }
}
