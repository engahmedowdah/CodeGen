﻿using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using CodeGen.Global;

namespace GlobalGen.DataAccess
{
    internal class clsGlobalDataAccessLayer
    {
        public enum enMode { AddNew, Update, GetAllData, FindDataByID, Delete, IsFoundByID};
        private enMode _Mode = enMode.AddNew;
        public string TableName {  get; set; }
        public string DatabaseName {  get; set; }
        public clsTable TableInfo { get; set; }
        public string FunctionName 
        {
            get
            {
                return _GetFunctionName();
            }
        }
        public clsGlobalDataAccessLayer(string DatabaseName, string TableName, enMode Mode)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
            this.TableInfo = clsTable.GetTableByName(DatabaseName,TableName);
            this._Mode = Mode;
        }

        private List<clsColumn> _GetColumnListPrimaryKeys()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach(clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if(columnInfo.IsPrimaryKey)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }
        private List<clsColumn> _GetColumnListUnPrimaryKeys()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if (!columnInfo.IsPrimaryKey)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }
        private List<clsColumn> _GetColumnListUnPrimaryKeysAndNotNull()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if (!columnInfo.IsPrimaryKey && !columnInfo.IsNullable)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }
        private List<clsColumn> _GetColumnListUnPrimaryKeysAndNull()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if (columnInfo.IsNullable && !columnInfo.IsPrimaryKey)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }

        public StringBuilder GetFunctionInfo()
        {
            StringBuilder sb = new StringBuilder();
            if(_Mode == enMode.Delete || _Mode == enMode.IsFoundByID || _Mode== enMode.GetAllData)
            {
                sb.Append($"{_GetTypeFunction()} {_GetFunctionName()}({_CreateSignature()})");
            }
            else
            {
                sb.Append($"{_GetTypeFunction()} {_GetFunctionName()}({_CreateSignature()}, ref string Error)");
            }
            return sb;
        }
        private string _GetTypeFunction()
        {
            switch (_Mode)
            {
                case enMode.AddNew:
                    return "public static int";
                
                case enMode.Update:
                case enMode.FindDataByID:
                case enMode.IsFoundByID:
                case enMode.Delete:
                    return "public static bool";
                
                case enMode.GetAllData:
                    return "public static DataTable";
                
                default:
                    return "";  
            }
        }
        private string _GetFunctionName()
        {
            if (_Mode == enMode.GetAllData)
                return $"GetAll{this.TableInfo.PluralTableName}";

            else if (_Mode == enMode.FindDataByID)
                return $"Find{this.TableInfo.SingularTableName}ByID";

            else if (_Mode == enMode.IsFoundByID)
                return $"Is{this.TableInfo.SingularTableName}FoundByID";

            else
                return _Mode.ToString();
        }

        private StringBuilder _CreateSignature()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    return _CreateUnPrimaryKeys();

                case enMode.Update:
                    sb.Append(_CreatePrimaryKeys());
                    sb.Append(", ");
                    sb.Append(_CreateUnPrimaryKeys());
                    return sb;

                case enMode.FindDataByID:
                    sb.Append(_CreatePrimaryKeys());
                    sb.Append(", ");
                    sb.Append(_CreateRefUnPrimaryKeys());
                    return sb;

                case enMode.Delete:
                    return _CreatePrimaryKeys();

                case enMode.GetAllData:
                    return sb;

                case enMode.IsFoundByID:
                    return _CreatePrimaryKeys();
            }
            return sb;
        }

        public StringBuilder CreateCodeInsideFunction()
        {
            StringBuilder sb = new StringBuilder();
            switch(_Mode)
            {
                case enMode.AddNew:
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}int ID = -1;");
                    sb.Append($"{_UsingSqlConnectionGen()}");
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}{_CreateReturnText()}");
                    break;

                case enMode.Update:
                case enMode.Delete:
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}int RowsAffected = -1;");
                    sb.Append($"{_UsingSqlConnectionGen()}");
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}{_CreateReturnText()}");
                    break;

                case enMode.IsFoundByID:
                case enMode.FindDataByID:
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}bool IsFound = false;");
                    sb.Append($"{_UsingSqlConnectionGen()}");
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}{_CreateReturnText()}");
                    break;

                case enMode.GetAllData:
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}DataTable dt = new DataTable();");
                    sb.Append($"{_UsingSqlConnectionGen()}");
                    sb.AppendLine($"{clsUtil.CreateTabs(3)}{_CreateReturnText()}");
                    break;

            }
            return sb;
        }
        public StringBuilder CreateSignatureWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    return this._CreateUnPrimaryKeysWithoutTypes();

                case enMode.Update:
                    sb.Append(this._CreatePrimaryKeysWithoutTypes());
                    sb.Append(", ");
                    sb.Append(this._CreateUnPrimaryKeysWithoutTypes());
                    return sb;

                case enMode.FindDataByID:
                    sb.Append(this._CreatePrimaryKeysWithoutTypes());
                    sb.Append(", ");
                    sb.Append(this._CreateRefUnPrimaryKeysWithoutTypes());
                    return sb;

                case enMode.Delete:
                    return this._CreatePrimaryKeysWithoutTypes();

                case enMode.GetAllData:
                    return sb;

                case enMode.IsFoundByID:
                    return _CreatePrimaryKeysWithoutTypes();

            }
            return sb;
        }

        private StringBuilder _UsingSqlConnectionGen()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(3)}using (SqlConnection connection =\n{clsUtil.CreateTabs(3)}new SqlConnection(clsDataAccessSettings.ConnectionString))");
            sb.AppendLine($"{clsUtil.CreateTabs(3)}{{");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}connection.Open();");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}string query = @\"{_GenQuery()}\";");
            sb.AppendLine($"{_ExecuteWithExceptionHandling(_UsingSqlCommandGen())}");
            sb.AppendLine($"{clsUtil.CreateTabs(3)}}}");
            return sb;
        }
        private StringBuilder _GenQuery()
        {
            List<clsColumn> unPrimaryColumns = _GetColumnListUnPrimaryKeys();
            List<clsColumn> primaryColumns = _GetColumnListPrimaryKeys();

            switch (_Mode)
            {
                case enMode.AddNew:
                    return _GenerateInsertQuery(unPrimaryColumns);

                case enMode.Delete:
                    return _GenerateDeleteQuery(primaryColumns);

                case enMode.Update:
                    return _GenerateUpdateQuery(unPrimaryColumns, primaryColumns);

                case enMode.IsFoundByID:
                    return _GenerateIsFoundQuery(primaryColumns);

                case enMode.GetAllData:
                    return _GenerateGetAllDataQuery(primaryColumns, unPrimaryColumns);

                case enMode.FindDataByID:
                    return _GenerateFindDataByIDQuery(primaryColumns, unPrimaryColumns);

                default:
                    return new StringBuilder();
            }
        }

        private StringBuilder _GenerateInsertQuery(List<clsColumn> unPrimaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"INSERT INTO {TableInfo.TableName}\n{clsUtil.CreateTabs(4)}");
            sb.Append($"({string.Join(", ", unPrimaryColumns.Select(col => col.ColumnName))})");
            sb.Append($"\n{clsUtil.CreateTabs(4)}VALUES\n{clsUtil.CreateTabs(4)}");

            sb.Append($"({string.Join(", ", unPrimaryColumns.Select(col => "@" + col.ColumnName))})");
            sb.Append($"\n{clsUtil.CreateTabs(4)}SELECT SCOPE_IDENTITY();");
            return sb;
        }

        private StringBuilder _GenerateDeleteQuery(List<clsColumn> primaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"DELETE FROM {TableInfo.TableName}");
            sb.Append($"{clsUtil.CreateTabs(4)}WHERE\n{clsUtil.CreateTabs(4)}");

            AppendWhereClause(sb, primaryColumns);
            sb.Append(";");
            return sb;
        }

        private StringBuilder _GenerateUpdateQuery(List<clsColumn> unPrimaryColumns, List<clsColumn> primaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"UPDATE {TableInfo.TableName}");
            sb.Append($"{clsUtil.CreateTabs(4)}SET\n{clsUtil.CreateTabs(4)}");

            for (int i = 0; i < unPrimaryColumns.Count; i++)
            {
                sb.Append($"{unPrimaryColumns[i].ColumnName} = @{unPrimaryColumns[i].ColumnName}");
                if (i < unPrimaryColumns.Count - 1)
                {
                    sb.Append(",\n" + clsUtil.CreateTabs(4));
                }
            }

            sb.Append($"\n{clsUtil.CreateTabs(4)}WHERE\n{clsUtil.CreateTabs(4)}");
            AppendWhereClause(sb, primaryColumns);
            sb.Append(";");
            return sb;
        }

        private StringBuilder _GenerateIsFoundQuery(List<clsColumn> primaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"SELECT 1 AS IsFound");
            sb.Append($"\n{clsUtil.CreateTabs(4)}from {TableInfo.TableName}\n");
            sb.Append($"{clsUtil.CreateTabs(4)}WHERE\n{clsUtil.CreateTabs(4)}");

            AppendWhereClause(sb, primaryColumns);
            sb.Append(";");
            return sb;
        }

        private StringBuilder _GenerateGetAllDataQuery(List<clsColumn> primaryColumns, List<clsColumn> unPrimaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");

            AppendColumns(sb, primaryColumns);
            if (unPrimaryColumns.Count > 0)
            {
                sb.Append(", ");
            }
            AppendColumns(sb, unPrimaryColumns);
            sb.Append($"\n{clsUtil.CreateTabs(4)}from {TableInfo.TableName}");

            sb.Append(";");
            return sb;
        }

        private StringBuilder _GenerateFindDataByIDQuery(List<clsColumn> primaryColumns, List<clsColumn> unPrimaryColumns)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");

            AppendColumns(sb, primaryColumns);
            if (unPrimaryColumns.Count > 0)
            { 
                sb.Append(", "); 
            }
            AppendColumns(sb, unPrimaryColumns);
            sb.Append($"\n{clsUtil.CreateTabs(4)}from {TableInfo.TableName}");

            sb.Append($"\n{clsUtil.CreateTabs(4)}WHERE\n{clsUtil.CreateTabs(4)}");
            AppendWhereClause(sb, primaryColumns);

            sb.Append(";");
            return sb;
        }

        private void AppendColumns(StringBuilder sb, List<clsColumn> columns)
        {
            for (int i = 0; i < columns.Count; i++)
            {
                sb.Append(columns[i].ColumnName);
                if (i < columns.Count - 1)
                {
                    sb.Append(", ");
                }
            }
        }

        private void AppendWhereClause(StringBuilder sb, List<clsColumn> primaryColumns)
        {
            for (int i = 0; i < primaryColumns.Count; i++)
            {
                sb.Append($"{primaryColumns[i].ColumnName} = @{primaryColumns[i].ColumnName}");
                if (i < primaryColumns.Count - 1)
                {
                    sb.Append(" AND ");
                }
            }
        }


        private StringBuilder _CommandParametersGen()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    sb = _CommandParametersGenForUnPrimaryKeys();
                    break;

                case enMode.Delete:
                    sb = _CommandParametersGenForPrimaryKeys();
                    break;

                case enMode.Update:
                    sb.Append(_CommandParametersGenForPrimaryKeys());
                    sb.Append(_CommandParametersGenForUnPrimaryKeys());
                    break;

                case enMode.IsFoundByID:
                    sb = _CommandParametersGenForPrimaryKeys();
                    break;

                case enMode.GetAllData:
                    break;

                case enMode.FindDataByID:
                    sb.Append(_CommandParametersGenForPrimaryKeys());
                    break;

                default:
                    break;
            }
            return sb;
        }

        private StringBuilder _CommandParametersGenForPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            List<clsColumn> primaryColumns = _GetColumnListPrimaryKeys();
            foreach (clsColumn column in primaryColumns)
            {
                sb.AppendLine($"{clsUtil.CreateTabs(6)}command.Parameters.AddWithValue(\"@{column.ColumnName}\", {column.ColumnName});");
            }
            return sb;
        }

        private StringBuilder _CommandParametersGenForUnPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();


            foreach (clsColumn column in _GetColumnListUnPrimaryKeysAndNotNull())
            {
                sb.AppendLine($"{clsUtil.CreateTabs(7)}command.Parameters.AddWithValue(\"@{column.ColumnName}\", {column.ColumnName});");
            }

            foreach (clsColumn column in _GetColumnListUnPrimaryKeysAndNull())
            {
                sb.AppendLine($"{clsUtil.CreateTabs(7)}if({column.ColumnName} == {column.DefaultValue})");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}{{");
                sb.AppendLine($"{clsUtil.CreateTabs(8)}command.Parameters.AddWithValue(\"@{column.ColumnName}\", DBNull.Value);");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}}}");

                sb.AppendLine($"{clsUtil.CreateTabs(7)}else");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}{{");
                sb.AppendLine($"{clsUtil.CreateTabs(8)}command.Parameters.AddWithValue(\"@{column.ColumnName}\", {column.ColumnName});");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}}}");
            }

            sb.AppendLine($"{clsUtil.CreateTabs(7)}");
            return sb;
        }
        private StringBuilder _UsingSqlDataReaderGen(string code)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(6)}using (SqlDataReader reader = command.ExecuteReader())");
            sb.AppendLine($"{clsUtil.CreateTabs(6)}{{");
            sb.AppendLine(code);
            sb.AppendLine($"{clsUtil.CreateTabs(6)}}}");
            return sb;
        }
        private StringBuilder _InsideSqlDataReader()
        {
            StringBuilder sb = new StringBuilder();
            switch(_Mode)
            {
                case enMode.GetAllData:
                    sb = _InsideSqlDataReaderForGetAllData(); 
                    break;
                case enMode.FindDataByID:
                    sb = _InsideSqlDataReaderForFindDataByID();
                    break;
                case enMode.IsFoundByID:
                    sb = _InsideSqlDataReaderForIsDataFoundByID();
                    break;
                default:
                    sb = new StringBuilder();
                    break;
            }
            return sb;
        }

        private StringBuilder _InsideSqlDataReaderForFindDataByID()
        {
            StringBuilder sb = new StringBuilder();

            foreach (clsColumn column in _GetColumnListUnPrimaryKeysAndNull())
            {
                sb.AppendLine($"{clsUtil.CreateTabs(7)}if (reader[\"{column.ColumnName}\"] == DBNull.Value)");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}{{");
                sb.AppendLine($"{clsUtil.CreateTabs(8)}{column.ColumnName} = {column.DefaultValue};");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}}}");

                sb.AppendLine($"{clsUtil.CreateTabs(7)}else");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}{{");
                sb.AppendLine($"{clsUtil.CreateTabs(8)}{column.ColumnName} = ({column.DataType})reader[\"{column.ColumnName}\"];");
                sb.AppendLine($"{clsUtil.CreateTabs(7)}}}");
            }

            sb.AppendLine($"{clsUtil.CreateTabs(7)}IsFound = reader.HasRows;");
            return _UsingSqlDataReaderGen(sb.ToString());
        }

        private StringBuilder _InsideSqlDataReaderForGetAllData()
        {
            return _UsingSqlDataReaderGen($"{clsUtil.CreateTabs(7)}dt.Load(reader);");
        }

        private StringBuilder _InsideSqlDataReaderForIsDataFoundByID()
        {
            return _UsingSqlDataReaderGen($"{clsUtil.CreateTabs(7)}IsFound = reader.HasRows;");
        }

        private StringBuilder _ExecuteWithExceptionHandling(StringBuilder code)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(4)}try");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}{{");
            sb.Append(code);
            sb.AppendLine($"{clsUtil.CreateTabs(4)}}}");

            sb.AppendLine($"{clsUtil.CreateTabs(4)}catch (SqlException ex)");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}{{");

            if (_Mode != enMode.Delete && _Mode != enMode.IsFoundByID && _Mode != enMode.GetAllData)
            {
                sb.AppendLine($"{clsUtil.CreateTabs(5)}Error = (\"An error occurred while accessing the database: \" + ex.Message);");
            }

            sb.AppendLine($"{clsUtil.CreateTabs(4)}}}");

            sb.AppendLine($"{clsUtil.CreateTabs(4)}catch (Exception ex)");
            sb.AppendLine($"{clsUtil.CreateTabs(4)}{{");

            if (_Mode != enMode.Delete && _Mode != enMode.IsFoundByID && _Mode != enMode.GetAllData)
            {
                sb.AppendLine($"{clsUtil.CreateTabs(5)}Error = (\"An unexpected error occurred: \" + ex.Message);");
            }

            sb.AppendLine($"{clsUtil.CreateTabs(4)}}}");
            return sb;
        }
        private StringBuilder _UsingSqlCommandGen()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(5)}using (SqlCommand command = new SqlCommand(query, connection))");
            sb.AppendLine($"{clsUtil.CreateTabs(5)}{{");
            sb.Append($"{_CommandParametersGen()}");
            sb.Append($"{_InsideSqlCommand()}");
            sb.AppendLine($"{clsUtil.CreateTabs(5)}}}");
            return sb;
        }

        private StringBuilder _InsideSqlCommand()
        {
            StringBuilder sb = new StringBuilder();
            if (_Mode == enMode.IsFoundByID || _Mode == enMode.FindDataByID || _Mode == enMode.GetAllData)
            {
                sb.Append($"{_InsideSqlDataReader()}");
            }
            else if (_Mode == enMode.Update)
            {
                sb.Append($"{_InsideSqlCommandForUpdate()}");
            }
            else if (_Mode == enMode.Delete)
            {
                sb.Append($"{_InsideSqlCommandForDelete()}");
            }
            else if (_Mode == enMode.AddNew)
            {
                sb.Append($"{_InsideSqlCommandForAddNew()}");
            }
            sb.AppendLine();
            return sb;
        }

        private StringBuilder _InsideSqlCommandForAddNew()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(6)}object result = command.ExecuteScalar();");
            sb.AppendLine($"{clsUtil.CreateTabs(6)}if (result != null && int.TryParse(result.ToString(), out int InsertedID))");
            sb.AppendLine($"{clsUtil.CreateTabs(6)}{{");
            sb.AppendLine($"{clsUtil.CreateTabs(7)}ID = Convert.ToInt32(result);");
            sb.AppendLine($"{clsUtil.CreateTabs(6)}}}");
            return sb;
        }

        private StringBuilder _InsideSqlCommandForUpdate()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(6)}RowsAffected = command.ExecuteNonQuery();");
            return sb;
        }

        private StringBuilder _InsideSqlCommandForDelete()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{clsUtil.CreateTabs(6)}RowsAffected = command.ExecuteNonQuery();");
            return sb;
        }

        private string _CreateReturnText()
        {
            string ReturnText = "";
            switch (_Mode)
            {
                case enMode.AddNew:
                    ReturnText = $"return ID;";
                    return ReturnText;

                case enMode.Update:
                case enMode.Delete:
                    ReturnText = $"return RowsAffected != -1;";
                    return ReturnText;

                case enMode.FindDataByID:
                case enMode.IsFoundByID:
                    ReturnText = $"return IsFound;";
                    return ReturnText;

                case enMode.GetAllData:
                    ReturnText = $"return dt;";
                    return ReturnText;
            }
            return ReturnText;
        }

        private StringBuilder _CreatePrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }

        private StringBuilder _CreateUnPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreateRefUnPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreatePrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        private StringBuilder _CreateUnPrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreateRefUnPrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        public static StringBuilder CreateUnPrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        public static StringBuilder CreateRefUnPrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        public static StringBuilder CreatePrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }

    }
}
