﻿using CodeGen_Business;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalGen.Business;
using CodeGen.Global;

namespace GlobalGen.Business
{
    internal class clsGlobalBusinessLayer
    {
        public enum enMode { AddNew, Update, GetAllData, GetDataByID, Delete, IsFoundByID , Save, Class};
        private enMode _Mode = enMode.AddNew;
        public string TableName { get; set; }
        public string DatabaseName { get; set; }
        public clsTable TableInfo { get; set; }
        public string FunctionName
        {
            get
            {
                return _GetFunctionName();
            }
        }
        public clsGlobalBusinessLayer(string DatabaseName, string TableName, enMode Mode)
        {
            this.TableName = TableName;
            this.DatabaseName = DatabaseName;
            this.TableInfo = clsTable.GetTableByName(DatabaseName,TableName);
            this._Mode = Mode;
        }

        private List<clsColumn> _GetColumnListPrimaryKeys()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if (columnInfo.IsPrimaryKey)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }
        private List<clsColumn> _GetColumnListUnPrimaryKeys()
        {
            List<clsColumn> columns = new List<clsColumn>();
            foreach (clsColumn columnInfo in TableInfo.ColumnsList)
            {
                if (!columnInfo.IsPrimaryKey)
                {
                    columns.Add(columnInfo);
                }
            }
            return columns;
        }
        public StringBuilder GetFunctionInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{_GetTypeFunction()} {_GetFunctionName()}({_CreateSignature()})");
            return sb;
        }
        public StringBuilder GetClassInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{_GetTypeFunction()} {_GetFunctionName()}");
            return sb;
        }
        private string _GetTypeFunction()
        {
            switch (_Mode)
            {
                case enMode.Update:
                case enMode.AddNew:
                    return "private bool";

                case enMode.GetDataByID:
                    return $"public static {this.TableInfo.BusinessClassName}";
                case enMode.IsFoundByID:
                case enMode.Delete:
                    return "public static bool";

                case enMode.GetAllData:
                    return "public static DataTable";
                case enMode.Save:
                    return "public bool";
                case enMode.Class:
                    return "public class";
                default:
                    return "";
            }
        }
        private string _GetFunctionName()
        {
            if (_Mode == enMode.GetAllData)
                return $"GetAll{TableInfo.PluralTableName}";
            else if (_Mode == enMode.GetDataByID)
                return $"Get{TableInfo.SingularTableName}ByID";
            else if (_Mode == enMode.AddNew)
                return "_AddNew";
            else if (_Mode == enMode.Update)
                return "_Update";
            else if (_Mode == enMode.Class)
                return $"{TableInfo.BusinessClassName}";
            else if (_Mode == enMode.IsFoundByID)
                return $"Is{TableInfo.SingularTableName}FoundByID";
            else
                return _Mode.ToString();
        }

        private StringBuilder _CreateSignature()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                case enMode.Update:
                case enMode.GetAllData:
                case enMode.Save:
                    return sb;

                case enMode.GetDataByID:
                case enMode.IsFoundByID:
                case enMode.Delete:
                    sb.Append(_CreatePrimaryKeys());
                    return sb;
            }
            return sb;
        }

        public StringBuilder CreateSignatureWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            switch (_Mode)
            {
                case enMode.AddNew:
                    return sb;

                case enMode.Update:
                    return sb;

                case enMode.GetDataByID:
                    sb.Append(this._CreatePrimaryKeysWithoutTypes());
                    return sb;

                case enMode.Delete:
                    sb.Append(this._CreatePrimaryKeysWithoutTypes());
                    return sb;

                case enMode.GetAllData:
                    return sb;

                case enMode.Save:
                    return sb;

            }
            return sb;
        }

        public string CreateReturnText()
        {
            StringBuilder returnTextBuilder = new StringBuilder();
            string databaseClass = TableInfo.DataAccessClassName;
            string singularTableName = TableInfo.SingularTableName;
            string pluralTableName = TableInfo.PluralTableName;

            switch (_Mode)
            {
                case enMode.GetAllData:
                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {databaseClass}.GetAll{pluralTableName}({this.CreateSignatureWithoutTypes()});");
                    break;

                case enMode.IsFoundByID:
                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {databaseClass}.IsFound{singularTableName}ByID({this._CreatePrimaryKeysWithoutTypes()});");
                    break;

                case enMode.Delete:
                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {databaseClass}.Delete({this._CreatePrimaryKeysWithoutTypes()});");
                    break;

                case enMode.AddNew:
                    var columns = _GetColumnListPrimaryKeys();
                    if (columns != null && columns.Count > 0)
                    {
                        returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}{columns[0].ColumnName} = {databaseClass}.AddNew({this._CreateUnPrimaryKeysWithoutTypes()});");
                        returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {columns[0].ColumnName} != -1;");
                    }
                    break;

                case enMode.Update:
                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {databaseClass}.Update({string.Join(", ", this._CreatePrimaryKeysWithoutTypes(), this._CreateUnPrimaryKeysWithoutTypes())}, ref Error);");
                    break;

                case enMode.GetDataByID:
                    var table = clsTable.GetTableByName(DatabaseName, TableName);
                    foreach (var column in table.ColumnsList)
                    {
                        if (!column.IsPrimaryKey)
                        {
                            returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}{column.DataType} {column.ColumnName} = {column.DefaultValue};");
                        }
                    }
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}string Error = \"\";");
                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}return {databaseClass}.Find{singularTableName}InfoByID({string.Join(", ", this._CreatePrimaryKeysWithoutTypes(), this._CreateRefUnPrimaryKeysWithoutTypes())}, ref Error);");
                    break;

                case enMode.Save:
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}if (_Mode == enMode.Update)");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}{{");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}return _Update();");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}}}");

                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}else");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(3)}{{");

                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}if (_AddNew())");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}{{");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(5)}_Mode = enMode.Update;");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(5)}return true;");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}}}");

                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}else ");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}{{");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(5)}return false;");
                    returnTextBuilder.AppendLine($"{clsUtil.CreateTabs(4)}}}");

                    returnTextBuilder.Append($"{clsUtil.CreateTabs(3)}}}");
                    break;
            }

            return returnTextBuilder.ToString();
        }
        private StringBuilder _CreatePrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }

        private StringBuilder _CreateUnPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreateRefUnPrimaryKeys()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.DataType} {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreatePrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        private StringBuilder _CreateUnPrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        private StringBuilder _CreateRefUnPrimaryKeysWithoutTypes()
        {
            StringBuilder sb = new StringBuilder();
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }
        public static StringBuilder CreateUnPrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        public static StringBuilder CreateRefUnPrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (!column.IsPrimaryKey)
                    sb.Append($"ref {column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


        public static StringBuilder CreatePrimaryKeysWithoutTypes(string DatabaseName, string TableName)
        {
            StringBuilder sb = new StringBuilder();
            clsTable TableInfo = clsTable.GetTableByName(DatabaseName, TableName);
            foreach (clsColumn column in TableInfo.ColumnsList)
            {
                if (column.RowNum % 5 == 0)
                    sb.AppendLine();
                if (column.IsPrimaryKey)
                    sb.Append($"{column.ColumnName}, ");
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 2, 2);
            }
            return sb;
        }


    }
}
