﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGen.Global
{
    public static class clsGlobal
    {
        public enum enPermissions { All = -1, GetAllData = 1, GetDataByID = 2, AddNewUpdate = 4, IsDataFoundByID = 8, Delete = 16 }
        public static int Permissions { get; set; } = -1;
        public static string DatabaseName = ""; 
    }
}
