﻿using CodeGen.Global;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CodeGen.Global.clsGlobal;

namespace CodeGen
{
    public partial class frmSelectFunctions : Form
    {
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        private const int WM_NCLBUTTONDOWN = 0x00A1;
        private const int HTCAPTION = 0x0002;

        string DatabaseName {  get; set; }
        public frmSelectFunctions()
        {
            InitializeComponent();
            DatabaseName = clsGlobal.DatabaseName;
        }

        private void btnAdvancedGenerating_Click(object sender, EventArgs e)
        {
            frmAdvancedGenerating advancedGenerating = new frmAdvancedGenerating();
            advancedGenerating.ShowDialog();
            this.Hide();
        }
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;

            if (checkBox.Checked)
            {
                clsGlobal.Permissions |= Convert.ToInt32(checkBox.Tag);
            }
            else
            {
                clsGlobal.Permissions &= ~Convert.ToInt32(checkBox.Tag);
                CountAllPermissions();
            }
        }
        private void frmSelectFunctions_Load(object sender, EventArgs e)
        {
            CheckForPermissions();
        }


        private void CheckForPermissions()
        {
            if (clsGlobal.Permissions == (int)enPermissions.All)
            {
                chbGetAllData.Checked = true;
                chbFindDataByID.Checked = true;
                chbAddNewUpdate.Checked = true;
                chbIsDataFoundByID.Checked = true;
                chbDelete.Checked = true;
            }
            else
            {
                chbGetAllData.Checked = (clsGlobal.Permissions & (int)enPermissions.GetAllData) != 0;
                chbFindDataByID.Checked = (clsGlobal.Permissions & (int)enPermissions.GetDataByID) != 0;
                chbAddNewUpdate.Checked = (clsGlobal.Permissions & (int)enPermissions.AddNewUpdate) != 0;
                chbIsDataFoundByID.Checked = (clsGlobal.Permissions & (int)enPermissions.IsDataFoundByID) != 0;
                chbDelete.Checked = (clsGlobal.Permissions & (int)enPermissions.Delete) != 0;
            }
        }

        private void CountAllPermissions()
        {
            if (clsGlobal.Permissions == (int)enPermissions.All)
            {
                return;
            }

            List<CheckBox> chbsPermissions = new List<CheckBox>()
            {
                chbGetAllData,
                chbFindDataByID,
                chbAddNewUpdate,
                chbIsDataFoundByID,
                chbDelete
            };

            clsGlobal.Permissions = 0; 
            int checkedCount = 0; 

            chbsPermissions.ForEach(chb =>
            {
                if (chb.Checked)
                {
                    clsGlobal.Permissions |= Convert.ToInt32(chb.Tag); 
                    checkedCount++;
                }
            });
            if(chbsPermissions.Count == checkedCount)
            {
                clsGlobal.Permissions = Convert.ToInt32(clsGlobal.enPermissions.All);
            }
        }
        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            List<CheckBox> chbsPermissions = new List<CheckBox>()
            {
                chbGetAllData,
                chbFindDataByID,
                chbAddNewUpdate,
                chbIsDataFoundByID,
                chbDelete
            };

            if (clsGlobal.Permissions != (int)clsGlobal.enPermissions.All)
            {
                chbsPermissions.ForEach(chb => chb.Checked = true);
                clsGlobal.Permissions = (int)enPermissions.All;
            }
            else
            {
                chbsPermissions.ForEach(chb => chb.Checked = false);
                clsGlobal.Permissions = 0;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMinimizeScreen_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Panel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }
    }
}
