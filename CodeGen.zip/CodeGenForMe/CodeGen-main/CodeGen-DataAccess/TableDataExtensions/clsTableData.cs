using System;
using System.Data;
using System.Data.SqlClient;
using CodeGen_DataAccess;

namespace CodeGen_DataAccess
{
    public class clsTableData
    {
        public DataTable GetAllTables(string databaseName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT
                        ROW_NUMBER() OVER (ORDER BY t.name) AS TableID,
                        t.name AS TableName,
                        MAX(CASE
                            WHEN fk.referenced_object_id IS NOT NULL THEN 1
                            ELSE 0
                        END) AS IsLinked,
                        MAX(OBJECT_NAME(fk.referenced_object_id)) AS LinkedTableName
                    FROM sys.tables t
                    LEFT JOIN sys.foreign_keys fk ON t.object_id = fk.parent_object_id
                    WHERE t.name <> 'sysdiagrams'  -- This table adds other tables that I do not want to add.
                    GROUP BY t.name  -- To solve the problem of recurring tables
                    ORDER BY t.name;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    DataTable dt = new DataTable();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                    return dt;
                }
            }
        }

        public bool FindTableInfoByID(string databaseName, int tableID, ref string tableName, ref bool isLinked, ref string linkedTableName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT
                        t.name AS TableName,
                        CASE 
                            WHEN fk.referenced_object_id IS NOT NULL THEN 1 
                            ELSE 0 
                        END AS IsLinked,
                        OBJECT_NAME(fk.referenced_object_id) AS LinkedTableName
                    FROM (
                        SELECT 
                            t.name,
                            t.object_id,
                            ROW_NUMBER() OVER (ORDER BY t.name) AS TableID  -- Assigning TableID based on the order of TableName
                        FROM sys.tables t
                    ) AS t
                    LEFT JOIN sys.foreign_keys fk ON t.object_id = fk.parent_object_id
                    WHERE TableID = @TableID;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableID", tableID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            tableName = reader["TableName"].ToString();
                            isLinked = Convert.ToBoolean(reader["IsLinked"]);
                            linkedTableName = reader["LinkedTableName"] == DBNull.Value ? null : reader["LinkedTableName"].ToString();
                            return true;
                        }
                    }
                    return false;
                }
            }
        }

        public bool FindTableInfoByName(string databaseName, string tableName, ref int tableID, ref bool isLinked, ref string linkedTableName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT 
                        ROW_NUMBER() OVER (ORDER BY t.name) AS TableID,
                        CASE 
                            WHEN fk.referenced_object_id IS NOT NULL THEN 1 
                            ELSE 0 
                        END AS IsLinked,
                        OBJECT_NAME(fk.referenced_object_id) AS LinkedTableName
                    FROM sys.tables t
                    LEFT JOIN sys.foreign_keys fk ON t.object_id = fk.parent_object_id
                    WHERE t.name = @TableName;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            tableID = Convert.ToInt32(reader["TableID"]);
                            isLinked = Convert.ToBoolean(reader["IsLinked"]);
                            linkedTableName = reader["LinkedTableName"] == DBNull.Value ? null : reader["LinkedTableName"].ToString();
                            return true;
                        }
                    }
                    return false;
                }
            }
        }

        public bool IsTableFound(string databaseName, int tableID)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT COUNT(1) 
                    FROM (
                        SELECT 
                            ROW_NUMBER() OVER (ORDER BY t.name) AS TableID,
                            t.object_id 
                        FROM sys.tables t
                    ) AS t
                    WHERE TableID = @TableID;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableID", tableID);

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        public bool IsTableFound(string databaseName, string tableName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT COUNT(1) 
                    FROM sys.tables 
                    WHERE name = @TableName;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }
    }
}