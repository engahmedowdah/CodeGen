using System;
using System.Data;
using System.Data.SqlClient;
using CodeGen_DataAccess;

namespace CodeGen_DataAccess
{
    public class clsDatabaseData
    {
        public DataTable GetAllDatabases()
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"SELECT
                               name as DatabaseName, database_id as DatabaseID 
                               FROM sys.databases 
                               WHERE database_id > 4 
                               ORDER BY name";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    DataTable dt = new DataTable();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                    return dt;
                }
            }
        }

        public bool FindDatabaseInfoByID(int databaseID, ref string databaseName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = "SELECT name FROM sys.databases WHERE database_id = @DatabaseID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseID", databaseID);
                    
                    object result = command.ExecuteScalar();
                    
                    if (result != null)
                    {
                        databaseName = result.ToString();
                        return true;
                    }
                    return false;
                }
            }
        }

        public bool FindDatabaseInfoByName(string databaseName, ref int id)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = "SELECT database_id FROM sys.databases WHERE name = @DatabaseName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseName", databaseName);
                    
                    object result = command.ExecuteScalar();
                    
                    if (result != null)
                    {
                        id = Convert.ToInt32(result);
                        return true;
                    }
                    return false;
                }
            }
        }

        public bool IsDatabaseFound(int databaseID)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(1) FROM sys.databases WHERE database_id = @DatabaseID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseID", databaseID);
                    
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        public bool IsDatabaseFound(string databaseName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(1) FROM sys.databases WHERE name = @DatabaseName";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseName", databaseName);
                    
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }
    }
}
