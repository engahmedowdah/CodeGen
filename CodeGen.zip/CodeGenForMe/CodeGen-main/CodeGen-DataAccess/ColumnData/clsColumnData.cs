using System;
using System.Data;
using System.Data.SqlClient;
using CodeGen_DataAccess;

namespace CodeGen_DataAccess
{
    public class clsColumnData
    {
        public DataTable GetAllColumns(string databaseName, string tableName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                            SELECT
                                ROW_NUMBER() OVER (ORDER BY c.name) AS ColumnID,
                                c.name AS ColumnName,
                                CASE 
                                    WHEN t.name = 'int' THEN 'int'
                                    WHEN t.name = 'bigint' THEN 'long'
                                    WHEN t.name = 'smallint' THEN 'short'
                                    WHEN t.name = 'tinyint' THEN 'byte'
                                    WHEN t.name = 'bit' THEN 'bool'
                                    WHEN t.name = 'decimal' THEN 'decimal'
                                    WHEN t.name = 'numeric' THEN 'decimal'
                                    WHEN t.name = 'float' THEN 'double'
                                    WHEN t.name = 'real' THEN 'float'
                                    WHEN t.name = 'money' THEN 'decimal'
                                    WHEN t.name = 'smallmoney' THEN 'decimal'
                                    WHEN t.name = 'char' THEN 'string'
                                    WHEN t.name = 'varchar' THEN 'string'
                                    WHEN t.name = 'text' THEN 'string'
                                    WHEN t.name = 'nchar' THEN 'string'
                                    WHEN t.name = 'nvarchar' THEN 'string'
                                    WHEN t.name = 'ntext' THEN 'string'
                                    WHEN t.name = 'date' THEN 'DateTime'
                                    WHEN t.name = 'datetime' THEN 'DateTime'
                                    WHEN t.name = 'datetime2' THEN 'DateTime'
                                    WHEN t.name = 'smalldatetime' THEN 'DateTime'
                                    WHEN t.name = 'time' THEN 'TimeSpan'
                                    WHEN t.name = 'uniqueidentifier' THEN 'Guid'
                                    WHEN t.name = 'xml' THEN 'string'
                                    ELSE 'object' 
                                END AS DataType,
                                c.is_nullable AS IsNullable,
                                CASE WHEN pkc.column_id IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey,
                                CASE WHEN fk.parent_column_id IS NOT NULL THEN 1 ELSE 0 END AS IsForeignKey,
                                OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable,
                                COL_NAME(fk.referenced_object_id, fk.referenced_column_id) AS ReferencedColumn
                            FROM sys.columns c
                            INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
                            LEFT JOIN sys.indexes pk ON c.object_id = pk.object_id AND pk.is_primary_key = 1
                            LEFT JOIN sys.index_columns pkc ON pk.object_id = pkc.object_id AND pk.index_id = pkc.index_id AND c.column_id = pkc.column_id
                            LEFT JOIN sys.foreign_key_columns fk ON c.object_id = fk.parent_object_id AND c.column_id = fk.parent_column_id
                            WHERE c.object_id = OBJECT_ID(@TableName)
                            ORDER BY IsPrimaryKey DESC, c.name;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt;
        }

        public bool FindColumnInfoByID(string databaseName, string tableName, int columnID,
            ref string columnName, ref string dataType, ref bool isNullable,
            ref bool isPrimaryKey, ref bool isForeignKey,
            ref string referencedTable, ref string referencedColumn)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT 
                        ROW_NUMBER() OVER (ORDER BY c.name) AS ColumnID,
                        c.name AS ColumnName,
                        CASE 
                            WHEN t.name = 'int' THEN 'int'
                            WHEN t.name = 'bigint' THEN 'long'
                            WHEN t.name = 'smallint' THEN 'short'
                            WHEN t.name = 'tinyint' THEN 'byte'
                            WHEN t.name = 'bit' THEN 'bool'
                            WHEN t.name = 'decimal' THEN 'decimal'
                            WHEN t.name = 'numeric' THEN 'decimal'
                            WHEN t.name = 'float' THEN 'double'
                            WHEN t.name = 'real' THEN 'float'
                            WHEN t.name = 'money' THEN 'decimal'
                            WHEN t.name = 'smallmoney' THEN 'decimal'
                            WHEN t.name = 'char' THEN 'string'
                            WHEN t.name = 'varchar' THEN 'string'
                            WHEN t.name = 'text' THEN 'string'
                            WHEN t.name = 'nchar' THEN 'string'
                            WHEN t.name = 'nvarchar' THEN 'string'
                            WHEN t.name = 'ntext' THEN 'string'
                            WHEN t.name = 'date' THEN 'DateTime'
                            WHEN t.name = 'datetime' THEN 'DateTime'
                            WHEN t.name = 'datetime2' THEN 'DateTime'
                            WHEN t.name = 'smalldatetime' THEN 'DateTime'
                            WHEN t.name = 'time' THEN 'TimeSpan'
                            WHEN t.name = 'uniqueidentifier' THEN 'Guid'
                            WHEN t.name = 'xml' THEN 'string' 
                                
                            
                            ELSE 'object'
                        END AS DataType,
                        c.is_nullable AS IsNullable,
                        CASE WHEN pkc.column_id IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey,
                        CASE WHEN fk.parent_column_id IS NOT NULL THEN 1 ELSE 0 END AS IsForeignKey,
                        OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable,
                        COL_NAME(fk.referenced_object_id, fk.referenced_column_id) AS ReferencedColumn
                    FROM sys.columns c
                    INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
                    LEFT JOIN sys.indexes pk ON c.object_id = pk.object_id AND pk.is_primary_key = 1
                    LEFT JOIN sys.index_columns pkc ON pk.object_id = pkc.object_id AND pk.index_id = pkc.index_id AND c.column_id = pkc.column_id
                    LEFT JOIN sys.foreign_key_columns fk ON c.object_id = fk.parent_object_id AND c.column_id = fk.parent_column_id
                    WHERE c.object_id = OBJECT_ID(@TableName)
                    AND ROW_NUMBER() OVER (ORDER BY c.name) = @ColumnID;";  

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@ColumnID", columnID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            columnName = reader["ColumnName"].ToString();
                            dataType = reader["DataType"].ToString();
                            isNullable = Convert.ToBoolean(reader["IsNullable"]);
                            isPrimaryKey = Convert.ToBoolean(reader["IsPrimaryKey"]);
                            isForeignKey = Convert.ToBoolean(reader["IsForeignKey"]);
                            referencedTable = reader["ReferencedTable"] == DBNull.Value ? null : reader["ReferencedTable"].ToString();
                            referencedColumn = reader["ReferencedColumn"] == DBNull.Value ? null : reader["ReferencedColumn"].ToString();
                            return true;
                        }
                    }
                    return false;
                }
            }
        }

        public bool FindColumnInfoByName(string databaseName, string tableName, string columnName,
            ref int columnID, ref string dataType, ref bool isNullable,
            ref bool isPrimaryKey, ref bool isForeignKey,
            ref string referencedTable, ref string referencedColumn)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @" USE [" + databaseName + @"];
                            SELECT 
                                ROW_NUMBER() OVER (ORDER BY c.name) AS ColumnID,
                                c.name AS ColumnName,
                                CASE 
                                    WHEN t.name = 'int' THEN 'int'
                                    WHEN t.name = 'bigint' THEN 'long'
                                    WHEN t.name = 'smallint' THEN 'short'
                                    WHEN t.name = 'tinyint' THEN 'byte'
                                    WHEN t.name = 'bit' THEN 'bool'
                                    WHEN t.name = 'decimal' THEN 'decimal'
                                    WHEN t.name = 'numeric' THEN 'decimal'
                                    WHEN t.name = 'float' THEN 'double'
                                    WHEN t.name = 'real' THEN 'float'
                                    WHEN t.name = 'money' THEN 'decimal'
                                    WHEN t.name = 'smallmoney' THEN 'decimal'
                                    WHEN t.name = 'char' THEN 'string'
                                    WHEN t.name = 'varchar' THEN 'string'
                                    WHEN t.name = 'text' THEN 'string'
                                    WHEN t.name = 'nchar' THEN 'string'
                                    WHEN t.name = 'nvarchar' THEN 'string'
                                    WHEN t.name = 'ntext' THEN 'string'
                                    WHEN t.name = 'date' THEN 'DateTime'
                                    WHEN t.name = 'datetime' THEN 'DateTime'
                                    WHEN t.name = 'datetime2' THEN 'DateTime'
                                    WHEN t.name = 'smalldatetime' THEN 'DateTime'
                                    WHEN t.name = 'time' THEN 'TimeSpan'
                                    WHEN t.name = 'uniqueidentifier' THEN 'Guid'
                                    WHEN t.name = 'xml' THEN 'string' 
                                    ELSE 'object'
                                END AS DataType,
                                c.is_nullable AS IsNullable,
                                CASE WHEN pkc.column_id IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey,
                                CASE WHEN fk.parent_column_id IS NOT NULL THEN 1 ELSE 0 END AS IsForeignKey,
                                OBJECT_NAME(fk.referenced_object_id) AS ReferencedTable,
                                COL_NAME(fk.referenced_object_id, fk.referenced_column_id) AS ReferencedColumn
                            FROM sys.columns c
                            INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
                            LEFT JOIN sys.indexes pk ON c.object_id = pk.object_id AND pk.is_primary_key = 1
                            LEFT JOIN sys.index_columns pkc ON pk.object_id = pkc.object_id AND pk.index_id = pkc.index_id AND c.column_id = pkc.column_id
                            LEFT JOIN sys.foreign_key_columns fk ON c.object_id = fk.parent_object_id AND c.column_id = fk.parent_column_id
                            WHERE c.object_id = OBJECT_ID(@TableName)
                            AND c.name = @ColumnName;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@ColumnName", columnName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            columnID = Convert.ToInt32(reader["ColumnID"]);
                            dataType = reader["DataType"].ToString();
                            isNullable = Convert.ToBoolean(reader["IsNullable"]);
                            isPrimaryKey = Convert.ToBoolean(reader["IsPrimaryKey"]);
                            isForeignKey = Convert.ToBoolean(reader["IsForeignKey"]);
                            referencedTable = reader["ReferencedTable"] == DBNull.Value ? null : reader["ReferencedTable"].ToString();
                            referencedColumn = reader["ReferencedColumn"] == DBNull.Value ? null : reader["ReferencedColumn"].ToString();
                            return true;
                        }
                    }
                    return false;
                }
            }
        }

        public bool IsColumnFound(string databaseName, string tableName, int columnID)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT COUNT(1)
                    FROM sys.columns
                    WHERE object_id = OBJECT_ID(@TableName)
                        AND ROW_NUMBER() OVER (ORDER BY c.name) = @ColumnID;";  

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@ColumnID", columnID);

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        public bool IsColumnFound(string databaseName, string tableName, string columnName)
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string query = @"
                    USE [" + databaseName + @"];
                    SELECT COUNT(1)
                    FROM sys.columns
                    WHERE object_id = OBJECT_ID(@TableName)
                        AND name = @ColumnName;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TableName", tableName);
                    command.Parameters.AddWithValue("@ColumnName", columnName);

                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }
    }
}