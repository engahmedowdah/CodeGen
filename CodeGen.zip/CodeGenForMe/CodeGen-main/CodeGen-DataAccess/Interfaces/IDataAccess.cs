using System;
using System.Data;

namespace CodeGen_DataAccess.Interfaces
{
    public interface IDatabaseDataAccess
    {
        DataTable GetAllDatabases();
        bool FindDatabaseInfoByID(int databaseID, ref string databaseName);
        bool FindDatabaseInfoByName(string databaseName, ref int id);
        bool IsDatabaseFound(int databaseID);
        bool IsDatabaseFound(string databaseName);
    }

    public interface ITableDataAccess
    {
        DataTable GetAllTables(string databaseName);
        bool FindTableInfoByID(string databaseName, int tableID, ref string tableName, ref bool isLinked, ref string linkedTableName);
        bool FindTableInfoByName(string databaseName, string tableName, ref int tableID, ref bool isLinked, ref string linkedTableName);
        bool IsTableFound(string databaseName, int tableID);
        bool IsTableFound(string databaseName, string tableName);
    }

    public interface IColumnDataAccess
    {
        DataTable GetAllColumns(string databaseName, string tableName);
        bool FindColumnInfoByID(string databaseName, string tableName, int columnID, 
            ref string columnName, ref string dataType, ref bool isNullable, 
            ref bool isPrimaryKey, ref bool isForeignKey, ref string referencedTable, ref string referencedColumn);
        bool FindColumnInfoByName(string databaseName, string tableName, string columnName, 
            ref int columnID, ref string dataType, ref bool isNullable, 
            ref bool isPrimaryKey, ref bool isForeignKey, ref string referencedTable, ref string referencedColumn);
        bool IsColumnFound(string databaseName, string tableName, int columnID);
        bool IsColumnFound(string databaseName, string tableName, string columnName);
    }
}
