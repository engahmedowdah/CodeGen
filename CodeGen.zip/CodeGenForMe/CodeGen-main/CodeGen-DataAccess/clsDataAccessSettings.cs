using System;
using System.Configuration;

namespace CodeGen_DataAccess
{
    public static class clsDataAccessSettings
    {
        public static string ConnectionString
        {
            get
            {
                return "Data Source=.;Integrated Security=True;TrustServerCertificate=True;";
            }
        }
    }
}
