﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.TablesData
{
    internal class clsGetAllTables : IGetAllTables
    {
        public DataTable GetAllTables(string DatabaseName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string Query = @"SELECT ROW_NUMBER() OVER (ORDER BY TABLE_NAME),TABLE_NAME as TableName
                                 FROM INFORMATION_SCHEMA.TABLES
                                 WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG = @DatabaseName
                                 order by TABLE_NAME;";
                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseName", DatabaseName);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt;
        }
    }
}
