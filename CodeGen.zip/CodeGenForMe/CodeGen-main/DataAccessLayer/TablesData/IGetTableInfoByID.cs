﻿using System;
using System.Data;

namespace DataAccessLayer.Interfaces
{
    internal interface IGetTableByID
    {
        bool GetTableInfoByID(string DatabaseName,int ID);
    }
}
