﻿using System;
using System.Data;


namespace DataAccessLayer.Interfaces
{
    internal interface IGetAllTables
    {
        DataTable GetAllTables(string DatabaseName);
    }
}
