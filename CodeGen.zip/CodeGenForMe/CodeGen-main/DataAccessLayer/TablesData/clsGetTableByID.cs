﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.TablesData
{
    internal class clsGetAllTablesData : iget
    {
        private string databaseName;

        public clsGetAllTablesData(string dbName)
        {
            databaseName = dbName;
        }

        public DataTable GetAllData()
        {
            DataTable dt = new DataTable();

            string connectionString = $"Data Source=.;Initial Catalog={databaseName};Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
                    SELECT ROW_NUMBER() OVER (ORDER BY TABLE_NAME) AS RowNum, 
                           TABLE_NAME AS TableName
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_CATALOG = @DatabaseName
                    ORDER BY TABLE_NAME;";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@DatabaseName", databaseName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }

            return dt;
        }
}