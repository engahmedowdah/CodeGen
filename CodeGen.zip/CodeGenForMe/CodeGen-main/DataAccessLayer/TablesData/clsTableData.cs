﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;


namespace DataAccessLayer.TablesData
{
    internal class clsTableData
    {
        IGetAllTables GetAllTables;
        IGetTableByID GetTableByID;
    }
}
