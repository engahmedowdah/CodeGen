﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.CoulmnsData
{
    internal class clsColumnData
    {
        IGetAllColumns GetAllCoulmns;
        IGetColumnInfoByID GetCoulmnByID;


    }
}
