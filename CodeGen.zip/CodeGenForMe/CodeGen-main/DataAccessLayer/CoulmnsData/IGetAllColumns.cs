﻿using System;
using System.Data;


namespace DataAccessLayer.Interfaces
{
    internal interface IGetAllColumns
    {
        DataTable GetAllColumns();
    }
}
