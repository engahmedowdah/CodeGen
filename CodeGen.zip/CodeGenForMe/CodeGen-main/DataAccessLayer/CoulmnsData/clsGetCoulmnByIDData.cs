﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.CoulmnsData
{
    internal class clsGetCoulmnByIDData : IGetColumnInfoByID
    {
        public DataTable GetColumnInfoByID(int ID)
        {
            DataTable dt = new DataTable();


            return dt;
        }
    }
}
