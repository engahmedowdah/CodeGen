﻿using System;
using System.Data;

namespace DataAccessLayer.Interfaces
{
    internal interface IGetColumnInfoByID
    {
        DataTable GetColumnInfoByID(int ID);
    }
}
