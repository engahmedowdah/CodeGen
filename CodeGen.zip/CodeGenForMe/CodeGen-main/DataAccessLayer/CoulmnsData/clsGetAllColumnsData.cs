﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.CoulmnsData
{
    internal class clsGetAllColumnsData : IGetAllColumns
    {
        public DataTable GetAllColumns()
        {
            DataTable dt = new DataTable();

            return dt;
        }
    }
}
