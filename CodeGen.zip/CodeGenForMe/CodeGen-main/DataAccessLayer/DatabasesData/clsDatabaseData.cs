﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.DatabasesData
{
    internal class clsDatabaseData
    {
        IGetAllDatabases GetAllDatabases;
        IGetDatabaseInfoByID GetDatabaseByID;


    }


}
