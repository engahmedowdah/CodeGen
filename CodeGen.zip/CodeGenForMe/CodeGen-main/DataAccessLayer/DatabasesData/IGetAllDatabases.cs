﻿using System;
using System.Data;


namespace DataAccessLayer.Interfaces
{
    internal interface IGetAllDatabases
    {
        DataTable GetAllDatabases();
    }
}
