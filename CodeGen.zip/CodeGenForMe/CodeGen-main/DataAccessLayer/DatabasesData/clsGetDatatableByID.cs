﻿using CodeGenerator;
using DataAccessLayer.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer.DatabasesData
{
    public class clsGetDatatableByID : IGetDatabaseInfoByID
    {
        public DataTable GetDatabaseInfoByID(int ID)
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                connection.Open();
                string Query = @"WITH DatabaseList AS (
                                SELECT ROW_NUMBER() OVER (ORDER BY name) AS RowNum, name
                                FROM sys.databases
                                WHERE name NOT IN ('master', 'model', 'msdb', 'tempdb')
                                )
                                SELECT * FROM DatabaseList
                                WHERE RowNum = @RowNum;";
                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt;
        }
    }
}
