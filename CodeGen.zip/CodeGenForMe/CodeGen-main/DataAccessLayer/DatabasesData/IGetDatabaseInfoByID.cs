﻿using System;
using System.Data;

namespace DataAccessLayer.Interfaces
{
    internal interface IGetDatabaseInfoByID
    {
        DataTable GetDatabaseInfoByID(int ID);
    }
}
