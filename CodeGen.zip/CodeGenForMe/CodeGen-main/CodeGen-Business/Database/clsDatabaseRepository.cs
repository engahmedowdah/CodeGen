using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business.Interfaces;
using CodeGen_DataAccess;

namespace CodeGen_Business
{
    public class clsDatabaseRepository : IDatabaseRepository
    {
        private readonly clsDatabaseData _databaseData;
        private readonly ITableRepository _tableRepository;

        public clsDatabaseRepository(ITableRepository tableRepository)
        {
            _databaseData = new clsDatabaseData();
            _tableRepository = tableRepository;
        }

        public DataTable GetAllDatabases()
        {
            return _databaseData.GetAllDatabases();
        }

        public bool IsDatabaseFound(string databaseName)
        {
            return _databaseData.IsDatabaseFound(databaseName);
        }

        public bool IsDatabaseFound(int databaseID)
        {
            return _databaseData.IsDatabaseFound(databaseID);
        }

        public IDatabase GetDatabaseByID(int databaseID)
        {
            string databaseName = string.Empty;
            if (_databaseData.FindDatabaseInfoByID(databaseID, ref databaseName))
            {
                return new clsDatabase(_tableRepository, databaseName, databaseID);
            }
            return null;
        }

        public IDatabase GetDatabaseByName(string databaseName)
        {
            int databaseID = 0;
            if (_databaseData.FindDatabaseInfoByName(databaseName, ref databaseID))
            {
                return new clsDatabase(_tableRepository, databaseName, databaseID);
            }
            return null;
        }

        public List<IDatabase> GetAllDatabasesInList()
        {
            DataTable dt = GetAllDatabases();
            List<IDatabase> databasesList = new List<IDatabase>();
            
            foreach (DataRow row in dt.Rows)
            {
                databasesList.Add(new clsDatabase(
                    _tableRepository,
                    (string)row["name"],
                    (int)row["RowNum"]));
            }
            
            return databasesList;
        }
    }
}
