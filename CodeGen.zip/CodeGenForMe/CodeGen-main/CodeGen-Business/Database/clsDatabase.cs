using CodeGen_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business;


namespace CodeGen_Business
{
    public class clsDatabase 
    {
        public string DatabaseName { get; private set; }
        public int DatabaseID { get; private set; }
        public List<clsTable>TableList 
        {
            get
            {
                return clsTable.GetAllTablesInList(DatabaseName);
            }
        }
        public string DatabaseNameWithBusiness
        {
            get
            {
                return DatabaseName + "_Business";
            }
        }
        public string DatabaseNameWithDataAccess
        {
            get
            {
                return DatabaseName + "_DataAccess";
            }
        }
        public string DatabaseNameWithDataAccessSettings
        {
            get
            {
                return DatabaseName + "_DataAccessSettings";
            }
        }
        public string ClassWithDataAccessSettings
        {
            get
            {
                return "clsDataAccessSettings";
            }
        }

        public clsDatabase()
        {
            DatabaseName = "";
            DatabaseID = 0;
        }

        public clsDatabase(string databaseName, int databaseID)
        {
            DatabaseName = databaseName;
            DatabaseID = databaseID;
        }

        public static DataTable GetAllDatabases()
        {
            clsDatabaseData databaseData = new clsDatabaseData();   
            return databaseData.GetAllDatabases();
        }

        public static bool IsDatabaseFound(string databaseName)
        {
            clsDatabaseData databaseData = new clsDatabaseData();
            return databaseData.IsDatabaseFound(databaseName);
        }

        public static bool IsDatabaseFound(int databaseID)
        {
            clsDatabaseData databaseData = new clsDatabaseData();
            return databaseData.IsDatabaseFound(databaseID);
        }

        public static clsDatabase GetDatabaseByID(int DatabaseID)
        {
            string DatabaseName = "";
            clsDatabaseData databaseData = new clsDatabaseData();
            if (databaseData.FindDatabaseInfoByID(DatabaseID, ref DatabaseName))
            {
                return new clsDatabase(DatabaseName, DatabaseID);
            }
            return null;
        }

        public static clsDatabase GetDatabaseByName(string DatabaseName)
        {
            int DatabaseID = 0;
            clsDatabaseData databaseData = new clsDatabaseData();
            if (databaseData.FindDatabaseInfoByName(DatabaseName, ref DatabaseID))
            {
                return new clsDatabase(DatabaseName, DatabaseID);
            }
            return null;
        }

        public static List<clsDatabase> GetAllDatabasesInList()
        {
            DataTable dt = GetAllDatabases();
            List<clsDatabase> databasesList = new List<clsDatabase>();
            foreach (DataRow row in dt.Rows)
            {
                databasesList.Add(new clsDatabase((string)row["DatabaseName"], (int)row["DatabaseID"]));
            }
            return databasesList;
        }
    }
}
