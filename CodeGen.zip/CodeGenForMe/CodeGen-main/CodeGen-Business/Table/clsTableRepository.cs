using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business.Interfaces;
using CodeGen_DataAccess;

namespace CodeGen_Business
{
    public class clsTableRepository : ITableRepository
    {
        private readonly clsTableData _tableData;
        private readonly IColumnRepository _columnRepository;

        public clsTableRepository(IColumnRepository columnRepository)
        {
            _tableData = new clsTableData();
            _columnRepository = columnRepository;
        }

        public DataTable GetAllTables(string databaseName)
        {
            return _tableData.GetAllTables(databaseName);
        }

        public ITable FindTableInfoByID(string databaseName, int tableID)
        {
            string tableName = string.Empty;
            bool isLinked = false;
            string linkedTableName = string.Empty;

            if (_tableData.FindTableInfoByID(databaseName, tableID, ref tableName, ref isLinked, ref linkedTableName))
            {
                return clsTable.Create(_columnRepository, databaseName, tableID, tableName, isLinked, linkedTableName);
            }
            return null;
        }

        public ITable FindTableInfoByName(string databaseName, string tableName)
        {
            int tableID = -1;
            bool isLinked = false;
            string linkedTableName = string.Empty;

            if (_tableData.FindTableInfoByName(databaseName, tableName, ref tableID, ref isLinked, ref linkedTableName))
            {
                return clsTable.Create(_columnRepository, databaseName, tableID, tableName, isLinked, linkedTableName);
            }
            return null;
        }

        public bool IsTableFound(string databaseName, int tableID)
        {
            return _tableData.IsTableFound(databaseName, tableID);
        }

        public bool IsTableFound(string databaseName, string tableName)
        {
            return _tableData.IsTableFound(databaseName, tableName);
        }

        public List<ITable> GetAllTablesInList(string databaseName)
        {
            List<ITable> tables = new List<ITable>();
            DataTable dt = GetAllTables(databaseName);
            
            foreach (DataRow row in dt.Rows)
            {
                tables.Add(clsTable.Create(
                    _columnRepository,
                    (string)row["DatabaseName"],
                    (int)row["TableID"],
                    (string)row["TableName"],
                    (bool)row["IsLinked"],
                    (string)row["LinkedTableName"]));
            }
            
            return tables;
        }
    }
}
