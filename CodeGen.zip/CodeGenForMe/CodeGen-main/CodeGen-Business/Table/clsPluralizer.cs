﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace CodeGen.Global
{

    public class clsPluralizer
    {
        private static readonly Dictionary<string, string> irregularSingulars = new Dictionary<string, string>
    {
        { "man", "men" },
        { "woman", "women" },
        { "child", "children" },
        { "foot", "feet" },
        { "goose", "geese" },
        { "tooth", "teeth" },
        { "mouse", "mice" },
        { "cactus", "cacti" },
        { "fungus", "fungi" },
        { "narrative", "narratives" },
        { "criterion", "criteria" },
        { "phenomenon", "phenomena" },
        { "datum", "data" },
        { "medium", "media" },
        { "synopsis", "synopses" },
        { "thesis", "theses" },
        { "axis", "axes" },
        { "index", "indices" },
        { "octopus", "octopi" },
        { "bacterium", "bacteria" },
        { "alumnus", "alumni" },
        { "focus", "foci" },
        { "vice", "vices" },
        { "appendix", "appendices" },
        { "penny", "pennies" },
        { "crisis", "crises" },
        { "hypothesis", "hypotheses" },
        { "nucleus", "nuclei" },
        { "shelf", "shelves" },
        { "knife", "knives" },
        { "wife", "wives" },
        { "dictionary", "dictionaries" }
    };

        public static string ConvertToPlural(string word)
        {
            if (string.IsNullOrEmpty(word)) return word;

            word = clsSingularizer.ConvertToSingular(word);
            if (irregularSingulars.TryGetValue(word.ToLower(), out var plural))
                return plural;

            if (Regex.IsMatch(word, "y$", RegexOptions.IgnoreCase) && !Regex.IsMatch(word, "aye$", RegexOptions.IgnoreCase))
                return Regex.Replace(word, "y$", "ies", RegexOptions.IgnoreCase);
            if (Regex.IsMatch(word, "s$", RegexOptions.IgnoreCase) || Regex.IsMatch(word, "x$", RegexOptions.IgnoreCase) || Regex.IsMatch(word, "z$", RegexOptions.IgnoreCase) || Regex.IsMatch(word, "ch$", RegexOptions.IgnoreCase) || Regex.IsMatch(word, "sh$", RegexOptions.IgnoreCase))
                return word + "es";
            return word + "s";
        }

        public static List<string> ConvertListToPlural(List<string> words)
        {
            List<string> pluralWords = new List<string>();
            foreach (var word in words)
            {
                pluralWords.Add(ConvertToPlural(word));
            }
            return pluralWords;
        }
    }
}
