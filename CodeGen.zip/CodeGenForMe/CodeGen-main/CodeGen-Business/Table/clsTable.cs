using CodeGen_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business;
using CodeGen.Global;

namespace CodeGen_Business
{
    public class clsTable
    {

        public string DatabaseName { get; private set; }
        public string TableName { get; private set; }
        public List<clsColumn> ColumnsList 
        {
            get
            {
                return clsColumn.GetAllColumnsInList(DatabaseName, TableName);
            }
        }
        public int TableID { get; private set; }
        public bool IsLinked { get; private set; }
        public string LinkedTableName { get; private set; }

        public string BusinessClassName
        {
            get
            {
                return "cls" + clsSingularizer.ConvertToSingular(TableName);
            }
        }
        public string DataAccessClassName
        {
            get
            {
                return "cls" + clsSingularizer.ConvertToSingular(TableName) + "Data";
            }
        }

        public string SingularTableName
        {
            get
            {
                if (TableName == null)
                {
                    return null;
                }
                else
                {
                    return clsSingularizer.ConvertToSingular(TableName);
                }
            }
        }

        public string PluralTableName
        {
            get
            {
                if (TableName == null)
                {
                    return null;
                }
                else
                {
                    return clsPluralizer.ConvertToPlural(TableName);
                }
            }
        }

        public clsTable()
        {
            this.DatabaseName = "";
            this.TableID = 0;
            this.TableName = "";
            this.IsLinked = false;
            this.LinkedTableName = "";
        }

        private clsTable(string databaseName, int tableID, string tableName, bool isLinked, string linkedTableName)
        {
            this.DatabaseName = databaseName;
            this.TableID = tableID;
            this.TableName = tableName;
            this.IsLinked = isLinked;
            this.LinkedTableName = linkedTableName;
        }

        public static DataTable GetAllTables(string DatabaseName)
        {
            clsTableData tableData = new clsTableData();
            return tableData.GetAllTables(DatabaseName);
        }

        public static List<clsTable> GetAllTablesInList(string DatabaseName)
        {
            List<clsTable> Tables = new List<clsTable>();
            DataTable dt = new clsTableData().GetAllTables(DatabaseName);

            foreach (DataRow dataRow in dt.Rows)
            {
                int tableId = Convert.ToInt32(dataRow["TableID"]);
                string tableName = dataRow.Field<string>("TableName");

                bool isLinked = dataRow["isLinked"] != DBNull.Value && Convert.ToBoolean(dataRow["isLinked"]);
                string linkedTableName = dataRow.Field<string>("linkedTableName");

                Tables.Add(new clsTable(DatabaseName, tableId, tableName, isLinked, linkedTableName));
            }

            return Tables;
        }

        public static clsTable GetTableByID(string DatabaseName, int TableID)
        {
            clsTableData clsTableData = new clsTableData();
            string TableName = "";
            bool IsLinked = false;
            string LinkedTableName = "";
            if(clsTableData.FindTableInfoByID(DatabaseName, TableID, ref TableName, ref IsLinked, ref LinkedTableName))
            {
                return new clsTable(DatabaseName, TableID, TableName,IsLinked,  LinkedTableName);
            }
            else
            {
                return null;
            }
        }
        public static clsTable GetTableByName(string DatabaseName, string TableName)
        {
            clsTableData clsTableData = new clsTableData();
            int TableID = -1;
            bool IsLinked = false;
            string LinkedTableName = "";
            if (clsTableData.FindTableInfoByName(DatabaseName, TableName, ref TableID, ref IsLinked, ref LinkedTableName))
            {
                return new clsTable(DatabaseName, TableID, TableName, IsLinked, LinkedTableName);
            }
            else
            {
                return null;
            }
        }

        public static bool IsTableFoundByID(string DatabaseName, int TableID)
        {
            clsTableData clsTableData = new clsTableData();
            return clsTableData.IsTableFound(DatabaseName, TableID);
        }

        public static bool IsTableFoundByName(string DatabaseName, string TableName)
        {
            clsTableData clsTableData = new clsTableData();
            return clsTableData.IsTableFound(DatabaseName, TableName);
        }
    }
}
