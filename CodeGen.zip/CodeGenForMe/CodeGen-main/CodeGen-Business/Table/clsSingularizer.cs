﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

public class clsSingularizer
{
    private static readonly Dictionary<string, string> irregularPlurals = new Dictionary<string, string>
    {
        { "men", "man" },
        { "women", "woman" },
        { "children", "child" },
        { "feet", "foot" },
        { "geese", "goose" },
        { "teeth", "tooth" },
        { "mice", "mouse" },
        { "cacti", "cactus" },
        { "fungi", "fungus" },
        { "narratives", "narrative" },
        { "criteria", "criterion" },
        { "phenomena", "phenomenon" },
        { "data", "datum" },
        { "media", "medium" },
        { "synopses", "synopsis" },
        { "theses", "thesis" },
        { "axes", "axis" },
        { "indices", "index" },
        { "octopi", "octopus" },
        { "bacteria", "bacterium" },
        { "alumni", "alumnus" },
        { "foci", "focus" },
        { "vices", "vice" },
        { "appendices", "appendix" },
        { "pennies", "penny" },
        { "crises", "crisis" },
        { "hypotheses", "hypothesis" },
        { "nuclei", "nucleus" },
        { "shelves", "shelf" },
        { "knives", "knife" },
        { "wives", "wife" },
        { "dictionaries", "dictionary" },
        { "employees", "employee" },
        { "people", "person" }
    };

    public static string ConvertToSingular(string word)
    {
        if (string.IsNullOrEmpty(word)) return word;

        if (irregularPlurals.TryGetValue(word.ToLower(), out var singular))
            return singular;

        if (Regex.IsMatch(word, "ies$", RegexOptions.IgnoreCase))
            return Regex.Replace(word, "ies$", "y", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(word, "men$", RegexOptions.IgnoreCase))
            return Regex.Replace(word, "men$", "man", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(word, "oes$", RegexOptions.IgnoreCase))
            return Regex.Replace(word, "oes$", "o", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(word, "es$", RegexOptions.IgnoreCase) && word.Length > 2)
            return Regex.Replace(word, "es$", "", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(word, "s$", RegexOptions.IgnoreCase) && word.Length > 1)
            return Regex.Replace(word, "s$", "", RegexOptions.IgnoreCase);
        if (Regex.IsMatch(word, "ves$", RegexOptions.IgnoreCase))
            return Regex.Replace(word, "ves$", "f", RegexOptions.IgnoreCase);

        return word; 
    }

    public static List<string> ConvertListToSingular(List<string> words)
    {
        List<string> singularWords = new List<string>();
        foreach (var word in words)
        {
            singularWords.Add(ConvertToSingular(word));
        }
        return singularWords;
    }
}