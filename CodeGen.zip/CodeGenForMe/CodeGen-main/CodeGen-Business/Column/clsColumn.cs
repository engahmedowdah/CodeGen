﻿using CodeGen_DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business;

namespace CodeGen_Business
{
    public class clsColumn
    {
        public int RowNum { get; private set; }
        public string ColumnName { get; private set; }
        public string DataType { get; private set; }
        public bool IsNullable { get; private set; }
        public bool IsPrimaryKey { get; private set; }
        public bool IsForeignKey { get; private set; }
        public string ReferencedTable { get; private set; }
        public string ReferencedColumn { get; private set; }
        public string DatabaseName {  get; private set; }
        public string TableName {  get; private set; }
        public string DefaultValue 
        {
            get
            {
                return _DefaultValueMethod(DataType);
            }
        }
        private static string _DefaultValueMethod(string type)
        {
            string defaultValue;

            switch (type.ToLower())
            {
                case "int":
                case "integer":
                case "int32":
                    defaultValue = "0";
                    break;
                case "long":
                case "int64":
                    defaultValue = "0L";
                    break;
                case "short":
                case "int16":
                    defaultValue = "0";
                    break;
                case "byte":
                    defaultValue = "0";
                    break;
                case "bool":
                    defaultValue = "false";
                    break;
                case "decimal":
                    defaultValue = "0.0m";
                    break;
                case "double":
                    defaultValue = "0.0";
                    break;
                case "float":
                    defaultValue = "0.0f";
                    break;
                case "string":
                    defaultValue = "string.Empty";
                    break;
                case "datetime":
                    defaultValue = "DateTime.MinValue";
                    break;
                case "timespan":
                    defaultValue = "TimeSpan.Zero";
                    break;
                case "guid":
                    defaultValue = "Guid.Empty";
                    break;
                default:
                    defaultValue = "null";
                    break;
            }
            return defaultValue;
        }

        public clsColumn()
        { 
            this.RowNum = 0;
            this.ColumnName = string.Empty;
            this.DataType = string.Empty;
            this.IsNullable = false;
            this.IsPrimaryKey = false;
            this.IsForeignKey = false;
            this.ReferencedTable = string.Empty;
            this.ReferencedColumn = string.Empty;
            this.DatabaseName = string.Empty;
            this.TableName = string.Empty;
        }
        private clsColumn(string DatabaseName, string TableName, int rowNum, string columnName, string dataType, bool isNullable, 
            bool isPrimaryKey, bool isForeignKey, string referencedTable, string referencedColumn)
        {
            this.RowNum = rowNum;
            this.ColumnName = columnName;
            this.DataType = dataType;
            this.IsNullable = isNullable;
            this.IsPrimaryKey = isPrimaryKey;
            this.IsForeignKey = isForeignKey;
            this.ReferencedTable = referencedTable;
            this.ReferencedColumn = referencedColumn;
            this.DatabaseName = DatabaseName;
            this.TableName = TableName;
        }
        public static DataTable GetAllColumns(string DatabaseName, string TableName)
        {
            clsColumnData columnData = new clsColumnData();
            return columnData.GetAllColumns(DatabaseName, TableName);
        }
        public static clsColumn GetColumnInfoByColumnID(string DatabaseName, string TableName, int ID)
        {
            string ColumnName = string.Empty;
            string DataType = string.Empty;
            bool IsNullable = false;
            bool IsPrimaryKey = false;
            bool IsForeignKey = false;
            string ReferencedTable = string.Empty;
            string ReferencedColumn = string.Empty;

            clsColumnData columnData = new clsColumnData();
            if (columnData.FindColumnInfoByID(DatabaseName, TableName, ID, ref ColumnName, ref DataType,
                ref IsNullable, ref IsPrimaryKey, ref IsForeignKey, ref ReferencedTable, ref ReferencedColumn))
            {
                return new clsColumn(DatabaseName, TableName, ID, ColumnName, DataType, IsNullable,
                    IsPrimaryKey, IsForeignKey, ReferencedTable, ReferencedColumn);
            }
            return null;
        }
        public static clsColumn GetColumnInfoByColumnName(string DatabaseName, string TableName, string ColumnName)
        {
            int ColumnID = 0;
            string DataType = string.Empty;
            bool IsNullable = false;
            bool IsPrimaryKey = false;
            bool IsForeignKey = false;
            string ReferencedTable = string.Empty;
            string ReferencedColumn = string.Empty;

            clsColumnData columnData = new clsColumnData();
            if (columnData.FindColumnInfoByName(DatabaseName, TableName, ColumnName, ref ColumnID, ref DataType,
                ref IsNullable, ref IsPrimaryKey, ref IsForeignKey, ref ReferencedTable, ref ReferencedColumn))
            {
                return new clsColumn(DatabaseName,TableName, ColumnID, ColumnName, DataType, IsNullable,
                    IsPrimaryKey, IsForeignKey, ReferencedTable, ReferencedColumn);
            }
            return null;
        }
        public static bool IsColumnFound(string DatabaseName, string TableName, string ColumnName)
        {
            clsColumnData columnData = new clsColumnData();
            return columnData.IsColumnFound(DatabaseName, TableName, ColumnName);
        }
        public static bool IsColumnFound(string DatabaseName, string TableName, int ColumnID)
        {
            clsColumnData columnData = new clsColumnData();
            return columnData.IsColumnFound(DatabaseName, TableName, ColumnID);
        }
        public static List<clsColumn> GetAllColumnsInList(string DatabaseName, string TableName)
        {
            List<clsColumn> columns = new List<clsColumn>();
            DataTable dt = GetAllColumns(DatabaseName, TableName);

            foreach (DataRow row in dt.Rows)
            {
                string columnName = row.Field<string>("ColumnName");
                string cSharpDataType = row.Field<string>("DataType");
                bool isNullable = row["IsNullable"] != DBNull.Value && Convert.ToBoolean(row["IsNullable"]);
                bool isPrimaryKey = row["IsPrimaryKey"] != DBNull.Value && Convert.ToBoolean(row["IsPrimaryKey"]);
                bool isForeignKey = row["IsForeignKey"] != DBNull.Value && Convert.ToBoolean(row["IsForeignKey"]);
                string referencedTable = row.Field<string>("ReferencedTable");
                string referencedColumn = row.Field<string>("ReferencedColumn");

                columns.Add(new clsColumn(
                    DatabaseName,
                    TableName,
                    Convert.ToInt32(row["ColumnID"]),
                    columnName,
                    cSharpDataType,
                    isNullable,
                    isPrimaryKey,
                    isForeignKey,
                    referencedTable,
                    referencedColumn
                ));
            }
            return columns;
        }
    }
}
