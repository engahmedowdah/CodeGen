﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CodeGen.Global
{
    public class clsUtil
    {
        public static bool Createfile(string FolderPath, string FileName, string Content)
        {
            string FilePath = Path.Combine(FolderPath, FileName);
            try
            {
                if (File.Exists(FilePath))
                    return false;

                File.WriteAllText(FilePath, Content);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public static bool DoesFileExist(string FolderPath, string FileName)
        {
            string FilePath = Path.Combine(FolderPath, FileName);

            try
            {
                if (File.Exists(FilePath))
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static bool DoesFileExist(string FilePath)
        {
            try
            {
                if (File.Exists(FilePath))
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public static string CreateTabs(int numberOfTabs)
        {
            string[] Tabs = new string[] { "\t", "\t\t", "\t\t\t", "\t\t\t\t", "\t\t\t\t\t", "\t\t\t\t\t\t", "\t\t\t\t\t\t\t", "\t\t\t\t\t\t\t\t", "\t\t\t\t\t\t\t\t\t", };
            if (numberOfTabs < Tabs.Length)
            {
                return Tabs[numberOfTabs - 1];
            }

            return new string('\t', numberOfTabs);
        }

        public static string DefaultValue(string type)
        {
            string defaultValue;

            switch (type.ToLower())
            {
                case "varchar":
                case "nvarchar":
                case "text":
                    defaultValue = "string.Empty";
                    break;
                case "char":
                    defaultValue = "'\\0'";
                    break;
                case "int":
                case "integer":
                case "int32":
                    defaultValue = "0";
                    break;
                case "bigint":
                case "int64":
                    defaultValue = "0L";
                    break;
                case "smallint":
                case "short":
                    defaultValue = "0";
                    break;
                case "float":
                    defaultValue = "0.0f";
                    break;
                case "double":
                    defaultValue = "0.0";
                    break;
                case "decimal":
                    defaultValue = "0.0m";
                    break;
                case "tinyint":
                case "byte":
                    defaultValue = "0";
                    break;
                case "bit":
                case "bool":
                    defaultValue = "false";
                    break;
                case "datetime":
                case "smalldatetime":
                case "date":
                    defaultValue = "DateTime.MinValue";
                    break;
                case "time":
                    defaultValue = "TimeSpan.Zero";
                    break;
                case "json":
                case "xml":
                    defaultValue = "string.Empty";
                    break;
                case "binary":
                case "varbinary":
                    defaultValue = "new byte[0]";
                    break;
                default:
                    defaultValue = "null";
                    break;
            }
            return defaultValue;

        }
    }
}
