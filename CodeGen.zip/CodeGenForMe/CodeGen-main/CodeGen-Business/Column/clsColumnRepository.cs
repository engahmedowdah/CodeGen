using System;
using System.Collections.Generic;
using System.Data;
using CodeGen_Business.Interfaces;
using CodeGen_DataAccess;

namespace CodeGen_Business
{
    public class clsColumnRepository : IColumnRepository
    {
        private readonly clsColumnData _columnData;

        public clsColumnRepository()
        {
            _columnData = new clsColumnData();
        }

        public DataTable GetAllColumns(string databaseName, string tableName)
        {
            return _columnData.GetAllColumns(databaseName, tableName);
        }

        public IColumn GetColumnInfoByColumnID(string databaseName, string tableName, int id)
        {
            string columnName = string.Empty;
            string dataType = string.Empty;
            bool isNullable = false;
            bool isPrimaryKey = false;
            bool isForeignKey = false;
            string referencedTable = string.Empty;
            string referencedColumn = string.Empty;

            if (_columnData.FindColumnInfoByID(databaseName, tableName, id, ref columnName, ref dataType,
                ref isNullable, ref isPrimaryKey, ref isForeignKey, ref referencedTable, ref referencedColumn))
            {
                return new clsColumn(databaseName, tableName, id, columnName, dataType, isNullable,
                    isPrimaryKey, isForeignKey, referencedTable, referencedColumn);
            }
            return null;
        }

        public IColumn GetColumnInfoByColumnName(string databaseName, string tableName, string columnName)
        {
            int columnId = 0;
            string dataType = string.Empty;
            bool isNullable = false;
            bool isPrimaryKey = false;
            bool isForeignKey = false;
            string referencedTable = string.Empty;
            string referencedColumn = string.Empty;

            if (_columnData.FindColumnInfoByName(databaseName, tableName, columnName, ref columnId, ref dataType,
                ref isNullable, ref isPrimaryKey, ref isForeignKey, ref referencedTable, ref referencedColumn))
            {
                return new clsColumn(databaseName, tableName, columnId, columnName, dataType, isNullable,
                    isPrimaryKey, isForeignKey, referencedTable, referencedColumn);
            }
            return null;
        }

        public bool IsColumnFound(string databaseName, string tableName, string columnName)
        {
            return _columnData.IsColumnFound(databaseName, tableName, columnName);
        }

        public bool IsColumnFound(string databaseName, string tableName, int columnID)
        {
            return _columnData.IsColumnFound(databaseName, tableName, columnID);
        }
    }
}
