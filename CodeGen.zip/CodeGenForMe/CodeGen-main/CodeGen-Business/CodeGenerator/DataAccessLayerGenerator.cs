using System;
using System.Collections.Generic;
using System.Text;
using CodeGen_Business.Interfaces;

namespace CodeGen_Business.CodeGenerator
{
    public class DataAccessLayerGenerator : IDataAccessLayerGenerator
    {
        private readonly StringBuilder _sbDataAccessClass;
        private readonly List<IColumn> _columnsList;
        private readonly IColumn _primaryKeyColumn;
        private readonly string _databaseName;

        public string TableName { get; }
        public string TableSingularName { get; }
        public string TableClassName { get; }

        public DataAccessLayerGenerator(List<IColumn> columns, string tableName, string databaseName)
        {
            _sbDataAccessClass = new StringBuilder();
            _columnsList = columns;
            TableName = tableName;
            _databaseName = databaseName;

            _primaryKeyColumn = columns.Find(c => c.IsPrimaryKey);
            if (_primaryKeyColumn == null)
            {
                throw new ArgumentException($"No primary key found for table {tableName}");
            }

            TableSingularName = _primaryKeyColumn.ColumnName.Substring(0, _primaryKeyColumn.ColumnName.Length - 2);
            TableClassName = $"cls{TableSingularName}Data";
        }

        public string GenerateCode()
        {
            GenerateClassHeader();
            GenerateFindMethod();
            GenerateAddMethod();
            GenerateUpdateMethod();
            GenerateDeleteMethod();
            GenerateGetAllMethod();
            GenerateHelperMethods();
            GenerateClassFooter();

            return _sbDataAccessClass.ToString();
        }

        private void GenerateClassHeader()
        {
            _sbDataAccessClass.AppendLine("using System;");
            _sbDataAccessClass.AppendLine("using System.Collections.Generic;");
            _sbDataAccessClass.AppendLine("using System.Data;");
            _sbDataAccessClass.AppendLine("using System.Data.SqlClient;");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine($"namespace {_databaseName}.DataAccess");
            _sbDataAccessClass.AppendLine("{");
            _sbDataAccessClass.AppendLine($"    public class {TableClassName}");
            _sbDataAccessClass.AppendLine("    {");
        }

        private void GenerateFindMethod()
        {
            _sbDataAccessClass.AppendLine($"        public {TableSingularName} Find(int id)");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine("            using (SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString))");
            _sbDataAccessClass.AppendLine("            {");
            _sbDataAccessClass.AppendLine($"                string query = $\"SELECT * FROM {TableName} WHERE {_primaryKeyColumn.ColumnName} = @ID\";");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                using (SqlCommand command = new SqlCommand(query, connection))");
            _sbDataAccessClass.AppendLine("                {");
            _sbDataAccessClass.AppendLine("                    command.Parameters.AddWithValue(\"@ID\", id);");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                    connection.Open();");
            _sbDataAccessClass.AppendLine("                    using (SqlDataReader reader = command.ExecuteReader())");
            _sbDataAccessClass.AppendLine("                    {");
            _sbDataAccessClass.AppendLine("                        if (reader.Read())");
            _sbDataAccessClass.AppendLine("                        {");
            _sbDataAccessClass.AppendLine($"                            return MapToBusinessObject(reader);");
            _sbDataAccessClass.AppendLine("                        }");
            _sbDataAccessClass.AppendLine("                    }");
            _sbDataAccessClass.AppendLine("                }");
            _sbDataAccessClass.AppendLine("            }");
            _sbDataAccessClass.AppendLine("            return null;");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateAddMethod()
        {
            _sbDataAccessClass.AppendLine($"        public bool Add({TableSingularName} entity)");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine("            using (SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString))");
            _sbDataAccessClass.AppendLine("            {");
            
            // Generate INSERT query
            StringBuilder columns = new StringBuilder();
            StringBuilder values = new StringBuilder();
            foreach (var column in _columnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    columns.Append($"{column.ColumnName}, ");
                    values.Append($"@{column.ColumnName}, ");
                }
            }
            
            _sbDataAccessClass.AppendLine($"                string query = $\"INSERT INTO {TableName} ({columns.ToString().TrimEnd(',', ' ')}) " +
                                        $"VALUES ({values.ToString().TrimEnd(',', ' ')})\";");
            
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                using (SqlCommand command = new SqlCommand(query, connection))");
            _sbDataAccessClass.AppendLine("                {");
            
            // Add parameters
            foreach (var column in _columnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    _sbDataAccessClass.AppendLine($"                    command.Parameters.AddWithValue(\"@{column.ColumnName}\", entity.{column.ColumnName});");
                }
            }
            
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                    connection.Open();");
            _sbDataAccessClass.AppendLine("                    return command.ExecuteNonQuery() > 0;");
            _sbDataAccessClass.AppendLine("                }");
            _sbDataAccessClass.AppendLine("            }");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateUpdateMethod()
        {
            _sbDataAccessClass.AppendLine($"        public bool Update({TableSingularName} entity)");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine("            using (SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString))");
            _sbDataAccessClass.AppendLine("            {");
            
            // Generate UPDATE query
            StringBuilder setClause = new StringBuilder();
            foreach (var column in _columnsList)
            {
                if (!column.IsPrimaryKey)
                {
                    setClause.Append($"{column.ColumnName} = @{column.ColumnName}, ");
                }
            }
            
            _sbDataAccessClass.AppendLine($"                string query = $\"UPDATE {TableName} SET {setClause.ToString().TrimEnd(',', ' ')} " +
                                        $"WHERE {_primaryKeyColumn.ColumnName} = @{_primaryKeyColumn.ColumnName}\";");
            
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                using (SqlCommand command = new SqlCommand(query, connection))");
            _sbDataAccessClass.AppendLine("                {");
            
            // Add parameters
            foreach (var column in _columnsList)
            {
                _sbDataAccessClass.AppendLine($"                    command.Parameters.AddWithValue(\"@{column.ColumnName}\", entity.{column.ColumnName});");
            }
            
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                    connection.Open();");
            _sbDataAccessClass.AppendLine("                    return command.ExecuteNonQuery() > 0;");
            _sbDataAccessClass.AppendLine("                }");
            _sbDataAccessClass.AppendLine("            }");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateDeleteMethod()
        {
            _sbDataAccessClass.AppendLine($"        public bool Delete(int id)");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine("            using (SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString))");
            _sbDataAccessClass.AppendLine("            {");
            _sbDataAccessClass.AppendLine($"                string query = $\"DELETE FROM {TableName} WHERE {_primaryKeyColumn.ColumnName} = @ID\";");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                using (SqlCommand command = new SqlCommand(query, connection))");
            _sbDataAccessClass.AppendLine("                {");
            _sbDataAccessClass.AppendLine("                    command.Parameters.AddWithValue(\"@ID\", id);");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                    connection.Open();");
            _sbDataAccessClass.AppendLine("                    return command.ExecuteNonQuery() > 0;");
            _sbDataAccessClass.AppendLine("                }");
            _sbDataAccessClass.AppendLine("            }");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateGetAllMethod()
        {
            _sbDataAccessClass.AppendLine($"        public List<{TableSingularName}> GetAll()");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine($"            List<{TableSingularName}> results = new List<{TableSingularName}>();");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("            using (SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString))");
            _sbDataAccessClass.AppendLine("            {");
            _sbDataAccessClass.AppendLine($"                string query = \"SELECT * FROM {TableName}\";");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("                using (SqlCommand command = new SqlCommand(query, connection))");
            _sbDataAccessClass.AppendLine("                {");
            _sbDataAccessClass.AppendLine("                    connection.Open();");
            _sbDataAccessClass.AppendLine("                    using (SqlDataReader reader = command.ExecuteReader())");
            _sbDataAccessClass.AppendLine("                    {");
            _sbDataAccessClass.AppendLine("                        while (reader.Read())");
            _sbDataAccessClass.AppendLine("                        {");
            _sbDataAccessClass.AppendLine("                            results.Add(MapToBusinessObject(reader));");
            _sbDataAccessClass.AppendLine("                        }");
            _sbDataAccessClass.AppendLine("                    }");
            _sbDataAccessClass.AppendLine("                }");
            _sbDataAccessClass.AppendLine("            }");
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("            return results;");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateHelperMethods()
        {
            _sbDataAccessClass.AppendLine($"        private {TableSingularName} MapToBusinessObject(SqlDataReader reader)");
            _sbDataAccessClass.AppendLine("        {");
            _sbDataAccessClass.AppendLine($"            var entity = new {TableSingularName}();");
            _sbDataAccessClass.AppendLine();
            
            foreach (var column in _columnsList)
            {
                _sbDataAccessClass.AppendLine($"            entity.{column.ColumnName} = reader[\"{column.ColumnName}\"] == DBNull.Value ? " +
                                            $"{GetDefaultValue(column.DataType)} : ({GetCSharpDataType(column.DataType)})reader[\"{column.ColumnName}\"];");
            }
            
            _sbDataAccessClass.AppendLine();
            _sbDataAccessClass.AppendLine("            return entity;");
            _sbDataAccessClass.AppendLine("        }");
            _sbDataAccessClass.AppendLine();
        }

        private void GenerateClassFooter()
        {
            _sbDataAccessClass.AppendLine("    }");
            _sbDataAccessClass.AppendLine("}");
        }

        private string GetCSharpDataType(string sqlDataType)
        {
            switch (sqlDataType.ToLower())
            {
                case "int": return "int";
                case "bigint": return "long";
                case "smallint": return "short";
                case "tinyint": return "byte";
                case "bit": return "bool";
                case "decimal":
                case "money":
                case "numeric": return "decimal";
                case "float": return "float";
                case "real": return "double";
                case "datetime":
                case "smalldatetime": return "DateTime";
                case "char":
                case "nchar":
                case "varchar":
                case "nvarchar":
                case "text":
                case "ntext": return "string";
                default: return "object";
            }
        }

        private string GetDefaultValue(string dataType)
        {
            switch (GetCSharpDataType(dataType))
            {
                case "int":
                case "long":
                case "short":
                case "byte": return "0";
                case "bool": return "false";
                case "decimal":
                case "float":
                case "double": return "0";
                case "DateTime": return "DateTime.MinValue";
                case "string": return "string.Empty";
                default: return "null";
            }
        }
    }
}
