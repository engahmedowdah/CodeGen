using System;
using System.Collections.Generic;
using System.Text;
using CodeGen_Business.Interfaces;

namespace CodeGen_Business.CodeGenerator
{
    /// <summary>
    /// Generates business layer code for a database table
    /// </summary>
    public class BusinessLayerGenerator : IBusinessLayerGenerator
    {
        private readonly StringBuilder _sbBusinessClass;
        private readonly List<IColumn> _columnsList;
        private readonly IColumn _primaryKeyColumn;
        private readonly string _databaseName;
        private readonly string _dalClassName;

        public string TableName { get; }
        public string TableSingularName { get; }
        public string TableClassName { get; }
        public string BusinessNamespace { get; }
        public bool GenerateValidation { get; set; } = true;
        public bool GenerateDocumentation { get; set; } = true;

        public BusinessLayerGenerator(List<IColumn> columns, string tableName, string databaseName)
        {
            if (columns == null || columns.Count == 0)
                throw new ArgumentException("Columns list cannot be null or empty", nameof(columns));
            
            if (string.IsNullOrEmpty(tableName))
                throw new ArgumentException("Table name cannot be null or empty", nameof(tableName));
            
            if (string.IsNullOrEmpty(databaseName))
                throw new ArgumentException("Database name cannot be null or empty", nameof(databaseName));

            _sbBusinessClass = new StringBuilder();
            _columnsList = columns;
            TableName = tableName;
            _databaseName = databaseName;
            BusinessNamespace = $"{databaseName}.Business";

            _primaryKeyColumn = columns.Find(c => c.IsPrimaryKey);
            if (_primaryKeyColumn == null)
                throw new ArgumentException($"No primary key found for table {tableName}");

            TableSingularName = GetSingularName(tableName);
            TableClassName = "cls" + TableSingularName;
            _dalClassName = "cls" + TableSingularName + "Data";
        }

        public void Initialize(List<IColumn> columns, string tableName, string databaseName)
        {
            // Already initialized in constructor
        }

        public string GenerateCode()
        {
            try
            {
                GenerateClassHeader();
                GenerateProperties();
                GenerateConstructors();
                if (GenerateValidation)
                    GenerateValidationMethods();
                GenerateFindMethods();
                GenerateAddMethod();
                GenerateUpdateMethod();
                GenerateDeleteMethod();
                GenerateGetAllMethod();
                GenerateHelperMethods();
                GenerateClassFooter();

                return _sbBusinessClass.ToString();
            }
            catch (Exception ex)
            {
                throw new CodeGenerationException($"Error generating business layer code for {TableName}", ex);
            }
        }

        private void GenerateClassHeader()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("using System;");
                _sbBusinessClass.AppendLine("using System.Collections.Generic;");
                _sbBusinessClass.AppendLine($"using {_databaseName}.DataAccess;");
                _sbBusinessClass.AppendLine();
                _sbBusinessClass.AppendLine($"namespace {BusinessNamespace}");
                _sbBusinessClass.AppendLine("{");
                _sbBusinessClass.AppendLine($"    /// <summary>");
                _sbBusinessClass.AppendLine($"    /// Represents a {TableSingularName} entity in the business layer");
                _sbBusinessClass.AppendLine($"    /// </summary>");
                _sbBusinessClass.AppendLine($"    public class {TableClassName}");
                _sbBusinessClass.AppendLine("    {");
            }
            else
            {
                _sbBusinessClass.AppendLine("using System;");
                _sbBusinessClass.AppendLine("using System.Collections.Generic;");
                _sbBusinessClass.AppendLine($"using {_databaseName}.DataAccess;");
                _sbBusinessClass.AppendLine();
                _sbBusinessClass.AppendLine($"namespace {BusinessNamespace}");
                _sbBusinessClass.AppendLine("{");
                _sbBusinessClass.AppendLine($"    public class {TableClassName}");
                _sbBusinessClass.AppendLine("    {");
            }
        }

        private void GenerateProperties()
        {
            foreach (var column in _columnsList)
            {
                if (GenerateDocumentation)
                {
                    _sbBusinessClass.AppendLine($"        /// <summary>");
                    _sbBusinessClass.AppendLine($"        /// Gets or sets the {GetPropertyDescription(column.ColumnName)}");
                    _sbBusinessClass.AppendLine($"        /// </summary>");
                }
                _sbBusinessClass.AppendLine($"        public {GetCSharpDataType(column.DataType)} {column.ColumnName} {{ get; set; }}");
                _sbBusinessClass.AppendLine();
            }
        }

        private void GenerateConstructors()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Initializes a new instance of the {TableClassName} class");
                _sbBusinessClass.AppendLine("        /// </summary>");
            }
            _sbBusinessClass.AppendLine($"        public {TableClassName}()");
            _sbBusinessClass.AppendLine("        {");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateValidationMethods()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine("        /// Validates the current entity");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine("        /// <returns>True if valid, false otherwise</returns>");
            }
            _sbBusinessClass.AppendLine("        public bool IsValid()");
            _sbBusinessClass.AppendLine("        {");
            
            foreach (var column in _columnsList)
            {
                if (!column.IsNullable && !column.IsPrimaryKey)
                {
                    if (column.DataType.Contains("char"))
                    {
                        _sbBusinessClass.AppendLine($"            if (string.IsNullOrEmpty({column.ColumnName}))");
                        _sbBusinessClass.AppendLine("                return false;");
                    }
                }
            }
            
            _sbBusinessClass.AppendLine("            return true;");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateFindMethods()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Finds a {TableSingularName} by ID");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine($"        /// <param name=\"id\">The ID of the {TableSingularName}</param>");
                _sbBusinessClass.AppendLine($"        /// <returns>The {TableSingularName} if found, null otherwise</returns>");
            }
            _sbBusinessClass.AppendLine($"        public static {TableClassName} Find(int id)");
            _sbBusinessClass.AppendLine("        {");
            _sbBusinessClass.AppendLine($"            {_dalClassName} dal = new {_dalClassName}();");
            _sbBusinessClass.AppendLine($"            return dal.Find(id);");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateAddMethod()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Adds this {TableSingularName} to the database");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine("        /// <returns>True if successful, false otherwise</returns>");
            }
            _sbBusinessClass.AppendLine("        public bool Add()");
            _sbBusinessClass.AppendLine("        {");
            if (GenerateValidation)
            {
                _sbBusinessClass.AppendLine("            if (!IsValid())");
                _sbBusinessClass.AppendLine("                return false;");
                _sbBusinessClass.AppendLine();
            }
            _sbBusinessClass.AppendLine($"            {_dalClassName} dal = new {_dalClassName}();");
            _sbBusinessClass.AppendLine("            return dal.Add(this);");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateUpdateMethod()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Updates this {TableSingularName} in the database");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine("        /// <returns>True if successful, false otherwise</returns>");
            }
            _sbBusinessClass.AppendLine("        public bool Update()");
            _sbBusinessClass.AppendLine("        {");
            if (GenerateValidation)
            {
                _sbBusinessClass.AppendLine("            if (!IsValid())");
                _sbBusinessClass.AppendLine("                return false;");
                _sbBusinessClass.AppendLine();
            }
            _sbBusinessClass.AppendLine($"            {_dalClassName} dal = new {_dalClassName}();");
            _sbBusinessClass.AppendLine("            return dal.Update(this);");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateDeleteMethod()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Deletes this {TableSingularName} from the database");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine("        /// <returns>True if successful, false otherwise</returns>");
            }
            _sbBusinessClass.AppendLine("        public bool Delete()");
            _sbBusinessClass.AppendLine("        {");
            _sbBusinessClass.AppendLine($"            {_dalClassName} dal = new {_dalClassName}();");
            _sbBusinessClass.AppendLine($"            return dal.Delete(this.{_primaryKeyColumn.ColumnName});");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateGetAllMethod()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine($"        /// Gets all {TableName} from the database");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine($"        /// <returns>List of {TableName}</returns>");
            }
            _sbBusinessClass.AppendLine($"        public static List<{TableClassName}> GetAll()");
            _sbBusinessClass.AppendLine("        {");
            _sbBusinessClass.AppendLine($"            {_dalClassName} dal = new {_dalClassName}();");
            _sbBusinessClass.AppendLine("            return dal.GetAll();");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateHelperMethods()
        {
            if (GenerateDocumentation)
            {
                _sbBusinessClass.AppendLine("        /// <summary>");
                _sbBusinessClass.AppendLine("        /// Converts the object to its string representation");
                _sbBusinessClass.AppendLine("        /// </summary>");
                _sbBusinessClass.AppendLine("        /// <returns>String representation of the object</returns>");
            }
            _sbBusinessClass.AppendLine("        public override string ToString()");
            _sbBusinessClass.AppendLine("        {");
            _sbBusinessClass.AppendLine($"            return $\"{TableSingularName} [ID={_primaryKeyColumn.ColumnName}]\";");
            _sbBusinessClass.AppendLine("        }");
            _sbBusinessClass.AppendLine();
        }

        private void GenerateClassFooter()
        {
            _sbBusinessClass.AppendLine("    }");
            _sbBusinessClass.AppendLine("}");
        }

        private string GetSingularName(string tableName)
        {
            // Remove common plural endings
            if (tableName.EndsWith("ies"))
                return tableName.Substring(0, tableName.Length - 3) + "y";
            if (tableName.EndsWith("s"))
                return tableName.Substring(0, tableName.Length - 1);
            return tableName;
        }

        private string GetPropertyDescription(string columnName)
        {
            // Convert PascalCase to space-separated words
            var result = new StringBuilder();
            for (int i = 0; i < columnName.Length; i++)
            {
                if (i > 0 && char.IsUpper(columnName[i]))
                    result.Append(' ');
                result.Append(columnName[i]);
            }
            return result.ToString();
        }

        private string GetCSharpDataType(string sqlDataType)
        {
            switch (sqlDataType.ToLower())
            {
                case "int": return "int";
                case "bigint": return "long";
                case "smallint": return "short";
                case "tinyint": return "byte";
                case "bit": return "bool";
                case "decimal":
                case "money":
                case "numeric": return "decimal";
                case "float": return "float";
                case "real": return "double";
                case "datetime":
                case "smalldatetime": return "DateTime";
                case "char":
                case "nchar":
                case "varchar":
                case "nvarchar":
                case "text":
                case "ntext": return "string";
                case "uniqueidentifier": return "Guid";
                default: return "object";
            }
        }
    }

    public class CodeGenerationException : Exception
    {
        public CodeGenerationException(string message) : base(message) { }
        public CodeGenerationException(string message, Exception innerException) : base(message, innerException) { }
    }
}
