using System;
using System.Text;
using CodeGen_Business.Interfaces;

namespace CodeGen_Business.CodeGenerator
{
    public class CodeGeneratorService : ICodeGeneratorService
    {
        private readonly ITableRepository _tableRepository;
        private readonly ICodeGeneratorFactory _generatorFactory;

        public CodeGeneratorService(ITableRepository tableRepository, ICodeGeneratorFactory generatorFactory)
        {
            _tableRepository = tableRepository;
            _generatorFactory = generatorFactory;
        }

        public string GenerateBusinessLayer(string databaseName, string tableName)
        {
            var table = _tableRepository.FindTableInfoByName(databaseName, tableName);
            if (table == null)
            {
                throw new ArgumentException($"Table {tableName} not found in database {databaseName}");
            }

            var generator = _generatorFactory.CreateBusinessGenerator(table.ColumnsList, tableName, databaseName);
            return generator.GenerateCode();
        }

        public string GenerateDataAccessLayer(string databaseName, string tableName)
        {
            var table = _tableRepository.FindTableInfoByName(databaseName, tableName);
            if (table == null)
            {
                throw new ArgumentException($"Table {tableName} not found in database {databaseName}");
            }

            var generator = _generatorFactory.CreateDataAccessGenerator(table.ColumnsList, tableName, databaseName);
            return generator.GenerateCode();
        }

        public string GenerateCompleteCode(string databaseName, string tableName)
        {
            var businessLayer = GenerateBusinessLayer(databaseName, tableName);
            var dataAccessLayer = GenerateDataAccessLayer(databaseName, tableName);

            var sb = new StringBuilder();
            sb.AppendLine("// Business Layer");
            sb.AppendLine(businessLayer);
            sb.AppendLine();
            sb.AppendLine("// Data Access Layer");
            sb.AppendLine(dataAccessLayer);

            return sb.ToString();
        }
    }
}
