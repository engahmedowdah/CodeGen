using System.Collections.Generic;
using CodeGen_Business.Interfaces;

namespace CodeGen_Business.CodeGenerator
{
    public class CodeGeneratorFactory : ICodeGeneratorFactory
    {
        public IBusinessLayerGenerator CreateBusinessGenerator(List<IColumn> columns, string tableName, string databaseName)
        {
            return new BusinessLayerGenerator(columns, tableName, databaseName);
        }

        public IDataAccessLayerGenerator CreateDataAccessGenerator(List<IColumn> columns, string tableName, string databaseName)
        {
            return new DataAccessLayerGenerator(columns, tableName, databaseName);
        }
    }
}
