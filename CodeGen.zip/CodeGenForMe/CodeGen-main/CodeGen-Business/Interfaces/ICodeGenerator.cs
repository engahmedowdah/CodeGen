using System;
using System.Collections.Generic;

namespace CodeGen_Business.Interfaces
{
    /// <summary>
    /// Base interface for all code generators
    /// </summary>
    public interface ICodeGenerator
    {
        /// <summary>
        /// Generates the code based on initialized parameters
        /// </summary>
        /// <returns>Generated code as string</returns>
        string GenerateCode();

        /// <summary>
        /// Initializes the code generator with required parameters
        /// </summary>
        /// <param name="columns">List of columns in the table</param>
        /// <param name="tableName">Name of the table</param>
        /// <param name="databaseName">Name of the database</param>
        void Initialize(List<IColumn> columns, string tableName, string databaseName);

        /// <summary>
        /// Gets the name of the table
        /// </summary>
        string TableName { get; }

        /// <summary>
        /// Gets the singular name of the table (used for class names)
        /// </summary>
        string TableSingularName { get; }

        /// <summary>
        /// Gets the class name for the generated code
        /// </summary>
        string TableClassName { get; }
    }

    /// <summary>
    /// Interface for business layer code generation
    /// </summary>
    public interface IBusinessLayerGenerator : ICodeGenerator
    {
        /// <summary>
        /// Gets the namespace for the business layer
        /// </summary>
        string BusinessNamespace { get; }

        /// <summary>
        /// Gets or sets whether to generate validation methods
        /// </summary>
        bool GenerateValidation { get; set; }

        /// <summary>
        /// Gets or sets whether to generate XML documentation
        /// </summary>
        bool GenerateDocumentation { get; set; }
    }

    /// <summary>
    /// Interface for data access layer code generation
    /// </summary>
    public interface IDataAccessLayerGenerator : ICodeGenerator
    {
        /// <summary>
        /// Gets the namespace for the data access layer
        /// </summary>
        string DataAccessNamespace { get; }

        /// <summary>
        /// Gets or sets whether to use stored procedures
        /// </summary>
        bool UseStoredProcedures { get; set; }

        /// <summary>
        /// Gets or sets whether to implement caching
        /// </summary>
        bool ImplementCaching { get; set; }
    }

    /// <summary>
    /// Interface for code generator factory
    /// </summary>
    public interface ICodeGeneratorFactory
    {
        /// <summary>
        /// Creates a business layer generator
        /// </summary>
        IBusinessLayerGenerator CreateBusinessLayerGenerator();

        /// <summary>
        /// Creates a data access layer generator
        /// </summary>
        IDataAccessLayerGenerator CreateDataAccessLayerGenerator();
    }

    /// <summary>
    /// Interface for code generator service
    /// </summary>
    public interface ICodeGeneratorService
    {
        /// <summary>
        /// Generates business layer code
        /// </summary>
        string GenerateBusinessLayer(List<IColumn> columns, string tableName, string databaseName);

        /// <summary>
        /// Generates data access layer code
        /// </summary>
        string GenerateDataAccessLayer(List<IColumn> columns, string tableName, string databaseName);

        /// <summary>
        /// Generates both business and data access layers
        /// </summary>
        (string businessLayer, string dataAccessLayer) GenerateAllLayers(List<IColumn> columns, string tableName, string databaseName);
    }
}
