using System;
using System.Collections.Generic;
using System.Data;

namespace CodeGen_Business.Interfaces
{
    public interface IDatabase
    {
        string DatabaseName { get; }
        int DatabaseID { get; }
        List<ITable> TableList { get; }
    }

    public interface IDatabaseRepository
    {
        DataTable GetAllDatabases();
        bool IsDatabaseFound(string databaseName);
        bool IsDatabaseFound(int databaseID);
        IDatabase GetDatabaseByID(int databaseID);
        IDatabase GetDatabaseByName(string databaseName);
        List<IDatabase> GetAllDatabasesInList();
    }
}
