using System;
using System.Data;

namespace CodeGen_Business.Interfaces
{
    public interface IColumn
    {
        int RowNum { get; }
        string ColumnName { get; }
        string DataType { get; }
        bool IsNullable { get; }
        bool IsPrimaryKey { get; }
        bool IsForeignKey { get; }
        string ReferencedTable { get; }
        string ReferencedColumn { get; }
        string DatabaseName { get; }
        string TableName { get; }
    }

    public interface IColumnRepository
    {
        DataTable GetAllColumns(string databaseName, string tableName);
        IColumn GetColumnInfoByColumnID(string databaseName, string tableName, int id);
        IColumn GetColumnInfoByColumnName(string databaseName, string tableName, string columnName);
        bool IsColumnFound(string databaseName, string tableName, string columnName);
        bool IsColumnFound(string databaseName, string tableName, int columnID);
    }
}
