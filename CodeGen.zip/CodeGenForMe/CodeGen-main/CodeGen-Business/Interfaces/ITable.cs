using System;
using System.Collections.Generic;
using System.Data;

namespace CodeGen_Business.Interfaces
{
    public interface ITable
    {
        string DatabaseName { get; }
        string TableName { get; }
        List<IColumn> ColumnsList { get; }
        int TableID { get; }
        bool IsLinked { get; }
        string LinkedTableName { get; }
    }

    public interface ITableRepository
    {
        DataTable GetAllTables(string databaseName);
        ITable FindTableInfoByID(string databaseName, int tableID);
        ITable FindTableInfoByName(string databaseName, string tableName);
        bool IsTableFound(string databaseName, int tableID);
        bool IsTableFound(string databaseName, string tableName);
        List<ITable> GetAllTablesInList(string databaseName);
    }
}
