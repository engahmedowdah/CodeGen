using System;
using System.Collections.Generic;

namespace CodeGen_Business.Interfaces
{
    public interface ICodeGeneratorBase
    {
        string TableName { get; }
        string TableSingularName { get; }
        string TableClassName { get; }
        string GenerateCode();
    }

    public interface ICodeGeneratorFactory
    {
        IBusinessLayerGenerator CreateBusinessGenerator(List<IColumn> columns, string tableName, string databaseName);
        IDataAccessLayerGenerator CreateDataAccessGenerator(List<IColumn> columns, string tableName, string databaseName);
    }

    public interface ICodeGeneratorService
    {
        string GenerateBusinessLayer(string databaseName, string tableName);
        string GenerateDataAccessLayer(string databaseName, string tableName);
        string GenerateCompleteCode(string databaseName, string tableName);
    }
}
