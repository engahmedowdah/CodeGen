using System;
using System.Collections.Generic;
using CodeGen_Business.Interfaces;

namespace CodeGen_Business.Services
{
    public class ServiceLocator
    {
        private static ServiceLocator _instance;
        private readonly Dictionary<Type, object> _services;

        private ServiceLocator()
        {
            _services = new Dictionary<Type, object>();
            RegisterServices();
        }

        public static ServiceLocator Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ServiceLocator();
                }
                return _instance;
            }
        }

        private void RegisterServices()
        {
            // Register repositories
            var columnRepository = new clsColumnRepository();
            var tableRepository = new clsTableRepository(columnRepository);
            var databaseRepository = new clsDatabaseRepository(tableRepository);

            _services[typeof(IColumnRepository)] = columnRepository;
            _services[typeof(ITableRepository)] = tableRepository;
            _services[typeof(IDatabaseRepository)] = databaseRepository;
        }

        public T GetService<T>() where T : class
        {
            if (_services.ContainsKey(typeof(T)))
            {
                return _services[typeof(T)] as T;
            }
            throw new InvalidOperationException($"Service of type {typeof(T)} is not registered");
        }
    }
}
